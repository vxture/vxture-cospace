# @vxture/design-system — 更新日志

发布走 `publish-design-system.yml`（GitHub Packages `npm.pkg.github.com`）。版本规则见
`docs/050-design-system-release.md` §2。

---

## 15.0.1 — 2026-11-07

### Shell panel rhythm and medal visibility

- ShellPanelRow, ShellPanelControlRow and ShellPanelSlots share 32px rows.
- Preference controls use the same 32px height and 8px gaps as action rows.
- Medal bases use 24px with 16px glyphs. Unearned medals stay neutral without
  additional opacity, so their presence remains clear.
- Affects all shell panels using these shared parts; description rows retain
  their natural two-line height. No product-side overrides are required.

## 15.0.0 — 2026-10-04

跟随 `@vxture/design-tokens@4.0.0` 与 `@vxture/design-ui@12.0.0`：排版 token
重命名、`title` 家族删除及 `SectionHeader level=4` 移除均为破坏性变化，因此伞包
同步升级 major。

- Shell 按钮、搜索框、选择器与面板行统一跟随收小后的控件高度阶梯，避免新字号体系下
  外壳控件仍显得过厚。
- 新增 `TenantInfoSimple`、`TenantInfoOneline`、`UserInfoSimple`、
  `UserInfoOneline`，供列表、选择器及正文中的身份展示；单行组件提供与正文行高对齐的
  `sm` 档。
- `ShellPanelMeterRow` 收窄右栏进度区，为窄面板的长标签保留空间；槽位标识按 24px
  行高缩为 20px。
- 通用单行控件采用稳定五档 `16/20/24/28/32px`，不再受密度轴改写；同名档的字号与
  图标规格一致。文字为 `10/12/12/14/14px`，图标为 `12/12/16/16/16px`；
  `40/48px` 仅供特殊页面形态。

- **标题阶梯最终校正**：本节覆盖下方 14.0.0 记录的中间方案；产品界面当前只使用
  `heading-1/2/3`，分别对应 `h1/h2/h3`，默认字号为 18 / 16 / 14px，Small 为
  16 / 14 / 12px，Large 为 20 / 18 / 16px。页头使用 `heading-1`；更大的文字统一
  交给 `display`。历史记录保留用于追溯。
- `ShellBootScreen` 标签从等值的原子组合 `text-sm + font-medium` 改为语义
  `text-label`；默认视觉不变，并会随 Small / Default / Large 字号模式切换。
- `ShellUserStatusTag` 的说明与当前 `StatusBadge` 规则对齐：`success` 默认带语义
  对勾，`neutral` 默认无图标。

## 14.0.0 — 2026-09-26

跟随 `@vxture/design-ui@11.0.0`（major：标题阶梯重排，level 即 h，页头改用 heading-3）。
伞包自身无 API 变化。

- 02-visual-spec §7「整页标题阶梯」重写：level 即 h，逐档列出元素 / 排版 / 图标 / 间距 / 描述 / 虚线；判据写明页头为何改用 heading-3。
- preview 的标题阶梯改用 DS 结构件：页头 `ViewHeader`（level 1，原为手写的营销页展示体 `heading-2`）、分组与基础页板块 `Section level 2`、组件条目 `Section level 3`（原为手写的两个 h2，字号倒挂）。「结构件族」示例按 level 1–4 重排，并入原「Section tone」条目。

## 13.6.0 — 2026-09-26

新增 `ShellHeaderTools`：顶栏标准工具箱（minor：新增件）。`@vxture/design-ui`
仍为 10.4.0。owner 2026-09-26 定顺序与交互。

- 六件、**固定顺序**：① 主题（点击切换）② 语言（弹出面板选择）③ 全屏（直接切换，
  需 `FullscreenProvider`）④ 帮助（新标签页，`href` 由调用方按当前页算出帮助主题）
  ⑤ 消息（侧边抽屉 `Drawer`，`unread` 小圆点，`onOpenChange`）⑥ 配置（当前页跳转
  后台配置）。顺序不由 prop 书写先后决定；不给的工具不渲染、不占位，一件都不给
  时整组不渲染。访客给前三件，登录后给全部六件。
- 主题图标表示**当前**主题（亮色太阳、暗色月亮，照 Figma），可访问名说点下去会
  怎样（`toDarkLabel` / `toLightLabel`）。
- 新增 `ShellToolboxLink`：工具箱里的链接，外观与 `ShellToolboxButton` 同一份；
  `ShellToolbox` 的 `items` 链接改由它渲染（外观不变）。
- 03-patterns-guide §7.1：顶栏右侧工具改用 `ShellHeaderTools`；preview「PageHeader」
  与「ShellToolbox」按标准顺序重排。

## 13.5.0 — 2026-09-26

四种页面 Header 照 Figma 重排；`ShellToolbox` 改为常态透明。跟随
`@vxture/design-ui@10.4.0`（`Badge` 新增 `size`、`ShellHeader` 槽间距统一 8px）。owner 2026-09-26，
Figma Header_website（2226:10298）/ Header_console_tenant（682:2224）/
Header_console_workforce（682:2225）/ Header_product（682:2226）。

- `ShellHeaderTitle`：标题文字加左右 `px-xs`（Figma BrandTitle 自带 8px）；`badge`
  改放在顶端对齐的 24px 上标位里（`data-slot="header-superscript"`），比标题略高。
- `ShellProductTitle`：`tier` 同样放进上标位，版位 32px（16px 小徽标抬得更明显）。
- 工作台两种的标题都改写平台名 vxture.ai（Figma 定稿），两种视角靠管理员徽标与
  分隔线后的内容区分。
- **`ShellToolbox` 常态透明**（修 bug，owner 2026-09-26）：此前常驻 `bg-background`
  灰底。现在平时无底；指针进入或键盘焦点落进组内时整组亮 `bg-accent`，指针所在
  的那个工具再亮一层 `bg-card`。悬停底比图标外扩 4px、以等量负外边距抵掉，胶囊
  尺寸与图标间距不变；未读圆点改贴悬停底的角。
- `ShellProductTitle` 的 `tier` 推荐 `<StatusBadge size="sm">`（Figma 46×18 的紧凑角标）。
- `ShellHeaderDomain`：去掉自带的 `px-2xs`，与竖线的距离由槽间距决定。
- 03-patterns-guide §7.1 按新稿重写：工作台三种高度 48px（缺省 `md`）、官网 64px；
  工具箱分访客组（主题 / 语言 / 全屏）与账户组（帮助 / 通知 / 设置）；单产品视角
  分隔线后改为当前租户；官网按钮 `size="sm"`。preview「PageHeader」同步。
- 与 Figma 的偏差：搜索框沿用 `ShellSearchBox`（32px 高、图标在左），Figma 用的是
  20px 高的 Legacy · Search 占位件；租户选择沿用 `ShellScopeButton`（label-md、
  12px 角标），Figma 是 body-md 弱化色 + 16px CaretDown。

## 13.4.0 — 2026-09-25

四种页面 Header 的零件（minor：新增件）。跟随 `@vxture/design-ui@10.3.0`
（`ShellHeader` 新增 `layout` / `surface`）。owner 2026-09-25，照 Figma
Header_website（2226:10298）/ Header_console（682:2224）/ Header_admin
（682:2225）/ Header_product（682:2226）。

- 新增 `ShellHeaderMark`（平台标识，32px 版位 24px 图形）、`ShellHeaderTitle`
  （品牌字体 24px 粗体标题，可带徽标）、`ShellHeaderDivider`（20px 竖线）、
  `ShellHeaderDomain`（当前域名，`label-lg` 弱化色）、`ShellProductTitle`（产品
  标识 + 名称 + 类型 + 等级）。
- 四种 header **不做成四个组件**，都是 `ShellHeader` 三槽里拼零件；选用判据写进
  03-patterns-guide §7.1，preview 新增「PageHeader」四种示例。
- 两种管理工作台以名称区分：租户用户工作台 Workspace Console（当前租户），平台
  管理工作台 Admin Console（管理员徽标 + 当前域）。
- 新增示例资源 `assets/examples/product-logo.png`：单产品视角演示用的产品标识，
  **只是示例**，各产品换成自己的。
- 与 Figma 的偏差：槽内间距沿用 `ShellHeader` 既有值（Figma 统一 8px）；示例里的
  智能体图标暂用平台标识占位。

## 13.3.0 — 2026-09-25

新增 `ShellToolbox` / `ShellToolboxButton`：外壳工具箱（minor：新增件）。owner
2026-09-25：支持显示 / 隐藏、链接、导入定义，样式照 Figma HeaderToolbar（123:43）。

- 外观：浅灰底（`bg-background`）圆角胶囊，图标 20px（`size-icon-md`）、间距
  `gap-md`，单个工具无底色，悬停与开启时提到前景色。整组 `role="toolbar"`。
- **按定义导入**：`items: ShellToolboxItem[]`——`key` / `icon` / `label`（必给，
  同时是悬停提示）/ `href`（给了就是链接，配 `newTab` / `linkComponent`）/
  `onClick` / `hidden` / `active`（报 `aria-pressed`）/ `disabled`（带 href 也退成
  禁用按钮）/ `badge`（右上角小圆点）。
- **自己组合**：children 里放 `ShellToolboxButton`（转发 ref、透传 props），可做
  `PopoverTrigger asChild`。不绑定弹层。定义的项在前、组合的项在后。
- **显隐**：`hidden` 的项不渲染、不占位；一项都不可见时整只胶囊不渲染。
- 与 Figma 的图形差异：全屏 / 通知 / 设置用字典现有的 `corners-out` / `bell` /
  `settings`；Figma 画的是 FrameCorners / BellSimple / GearSix。

## 13.2.0 — 2026-09-25

跟随 `@vxture/design-ui@10.2.0`（minor）：`InputOTP` 新增形态轴 `variant`；独立
方格格间距改为 8px（lg 此前 16px）。详见 design-ui 10.2.0。

## 13.1.0 — 2026-09-25

跟随 `@vxture/design-ui@10.1.0`（minor）：新增 `FieldValue`（表单的只读展示）与
`FieldGroup columns={3}`。详见 design-ui 10.1.0。

## 13.0.0 — 2026-09-25

跟随 `@vxture/design-ui@10.0.0`（major）：每页条数的 `"auto"` 档全面删除。
迁移见 design-ui 10.0.0 与发版说明 §02。

- 写了 `pageSize="auto"`、`pageSizeOptions` 含 `"auto"`、
  `useListPagination(rows, "auto")`、`pageSizeAutoLabel` 的地方：类型报错，改成
  具体条数 / 删掉参数。
- **`useListPagination(rows)` 不传条数的页面不报错，但行为会变**：每页由「一屏
  放几行」变成固定 20 条。

同时包含未单独发布的 12.23.0 各项（见下）。

## 12.23.0 — 2026-09-25

新增 `ShellUserPanel`（用户面板本体）与 `ShellPanelSurface`（面板的平铺外壳）
（minor：新增件，无删改）。

### `ShellPanelSurface`

`ShellPanelContent` 的不弹层版本：同宽（`w-80`）、同留白（`p-md`）、同段间距
（`gap-md`）、同表面（`panel.base` + `rounded-md`），不带阴影。

此前面板平铺时没有外壳组件，调用方只能手写一个 div，宽度、留白、边线各写各的
——本仓预览就曾把边线写成 `border border-border`，与弹层的
`ring-1 ring-foreground/10` 颜色与画法都不同。外壳归组件之后，各业务系统平铺
出来的面板与弹层里的逐像素一致。

### `ShellUserPanel`

- **组合使用**：`ShellUserMenu` 管入口（头像按钮、在线小点、弹层开合与落点），
  弹层里装的就是 `ShellUserPanel`；`ShellUserPanel` 也可以单独平铺，给抽屉、
  移动端账户页、预览面这类「不用点头像」的场合。两处是同一份代码。
- `ShellUserPanelProps`：`user` / `extras` / `settings` / `portalReturn` /
  `links` / `actions`，与 `ShellUserMenu` 的内容字段同一份；另有可选的
  `onItemSelect`（点了链接、动作、「回到来处」之后调用，叉掉提示不算）与
  `className`。
- 平铺时外壳走 `ShellPanelSurface`。
- `ShellUserMenuProps` 改为由 `ShellUserPanelProps` 派生，字段与此前逐项一致，
  **调用方无需改动**。
- preview：外壳页同时摆出头像按钮与平铺面板；ShellPanel 页的 TenantPanel 与
  ShellUserPanel 并排，两块外壳都走 `ShellPanelSurface`。内容照 Figma UserPanel
  （190:603）配，偏好设置用中文档名。

### `ShellPanelRow` 的 `strong` 档：纯数字，与 `ShellPanelMeterRow` 读数同款

**不用改代码，观感变了**：`valueTone="strong"`（账户余额、本月账单）不再套浅蓝
底色块，改为与 `ShellPanelMeterRow`（额度、存储）的读数**同一份渲染**：数字
label-xl（18px）、单位 label-sm（12px、弱化色）、间距 `gap-2xs`、底对齐。

此前两者各写一份：余额 16px 数字套 24px 高的底块，存储 18px 纯数字。同一块面板
里数字高度、单位位置对不上（owner 2026-09-25）。`valueTone` 的 API 不变，
`"muted"`（小灰字）不受影响。

### `ShellPanelMeterRow` 可点

新增 `href` / `linkComponent` / `onClick` / `newTab` / `chevron`，与
`ShellPanelRow` 同名同义（全部可选，不传即原行为）。两者共用内部的行外框
`RowFrame`：同一块面板里读数行（额度、存储）与普通行（余额、租户信息…）的
悬停、焦点、角标一致。去向由调用方给，DS 不认识任何控制台地址。

preview：TenantPanel 六个条目都可点，示意去向为租户控制台的对应页面。

### `ShellScopePanel` 排版优化（不用改代码，观感变了）

跟随 `@vxture/design-ui@9.13.0`（新增图标 `check-circle` 与 `workspace`）。owner 2026-09-25：
租户条目与工作区条目排列难看。逐项对照 Figma（2252:10089）后改四处：

- **组名不再比子项靠右**：组标题此前借用面板顶部的大头部，24px 图标占着 48px
  标识列，租户名文字起点 74px，而下面工作区文字起点 56px——子项比父级还靠左。
  `ShellPanelHeader` 新增 `compact`（仅 `lead="icon"` 生效，缺省 false）：图标
  不占标识列，组名左移到约 50px，与工作区文字大致同列。
- **子项缩进、文字与组名同列**：工作区图标缩进一档（`pl-md`）、改为 16px，图标与文字间距 `gap-xs`。默认密度下工作区文字起点 16 + 10 + 16 + 8 = 50px，与组名起点 10 + 24 + 16 = 50px 同列；紧凑 / 宽松密度差 4 / 2px。
- **统一行高**：工作区项有没有副行都占 `min-h-control-2xl`（默认密度 48px），
  不再单行项 38px、双行项 56px 忽高忽低。
- **只有当前所在项突出显示**：选中项 accent 底 + 主色字 + 圆形对勾
  （`check-circle`，20px，此前是 16px 细对勾）；其余项一律浅灰底
  （`bg-muted`），不分是否在当前租户下。

内距与间距保持 `sm`（默认密度 10px）：Figma 标的 12px 不在间距刻度上
（`sm` 10 / `md` 16），不为一处造刻度外的值。

## 12.22.0 — 2026-09-25

跟随 `@vxture/design-tokens@3.4.0`（minor）。详见 design-tokens 3.4.0。

- 新增 `text-code-lg`：code 族从两档变三档（默认 12 / 14 / 16px）。
- `title` 与 `overline` 字重降到 500。**调用方无需改代码**；用到
  `text-title-*` / `text-overline` 的标题观感变轻。

## 12.21.1 — 2026-09-25

跟随 `@vxture/design-tokens@3.3.1`（patch）：宽松密度的留白与行高与默认档真正
拉开（#59）。**调用方无需改代码**；只有挂了 `.density-comfortable` 的页面观感
会变，默认与紧凑不变。详见 design-tokens 3.3.1。

- 02 视觉规格 §4 改为：密度调留白、行高、控件高度三样，控件只动 ±1 档；任何
  一档不得与相邻档取值相同。
- 产品侧为宽松档自行加的过渡覆盖（ruyin `app.css` 里 `html.density-comfortable`
  那一段）升级后应删除，否则会叠加两次。

## 12.21.0 — 2026-09-25

`ShellSidebarNav` 新增 `subLabelReveal`：副名第二行何时现身（minor：新增可选
prop，缺省即原行为）。来自 karda（#47）。

- `"always"`（缺省）：副名常驻，与此前完全一致。
- `"active-hover"`：只在当前项、悬停、键盘聚焦时展开双行，离开恢复单行。导航
  常态保持安静，英文原词是「停下来对概念」时才需要的。
- 这一档下双行**不加 `py-2xs`**，三档字号下两行都落在 `min-h-control-xl`
  以内，展开前后行高不变，不会挤动下面的项。唯一例外是紧凑密度 + 大字号，
  仍会撑高约 1.5px。
- 副名对读屏始终可读：收起的可视行标 `aria-hidden`，另放一份 `sr-only` 副本，
  链接的可访问名与 `"always"` 一致，不会出现「当前项读得到副名、其余项读不到」。

**karda 可以删掉的**：TD-016 那段借内部 DOM 的作用域 CSS
（`.font-mono` + `aria-current` 选择器），改传 `subLabelReveal="active-hover"`。

## 12.20.0 — 2026-09-24

新增 `ShellScopePanel`——`ShellScopeButton` 点开后的那一层（minor：新增件 +
`ShellPanelHeader` 两个新槽位，无删改）。

### `ShellScopePanel`

两级：**组**与**项**。DS 不认识"租户"和"工作区"，只认识"若干组、每组若干项、
全局选中其中一项"——与 `ShellScopeButton` 同一句话：范围是什么由调用方定。

- 选中态由**一个** `value` 决定，而不是每个 option 自带 `active`。后者允许
  "两个组各自选中一项"这种画得出来但讲不通的状态。
- 语义照本仓既有的两处单选面板（`ShellLauncher` / `LocaleSelectPanel`）：
  `role="menu"` + `menuitemradio` + `aria-checked`，选中项尾部补对勾。
  **没有改用 `listbox`**——那套要求方向键在选项间移动，而这里每项都是原生
  按钮靠 Tab 走；只换角色名不实现方向键，等于向读屏器承诺一个不存在的操作方式。
- 非当前组标题整体降调：面板里同时列着好几个组，不降调的话"我在哪"要靠找那个
  可能在一屏之外的对勾。
- 组之间用 `Separator`，首组之前不画。

### `ShellPanelHeader`

- 新增 `lead`：`"avatar"`（默认，即原行为）/ `"icon"`（不画圆、只放图标）。
  主体是组织/项目时用后者——给一个组织画头像圈会让它看起来像个人。两档占同一
  列宽，同面板混用不错行。
- 新增 `tone`：`"default"`（默认）/ `"muted"`（标题降到副文级）。

### 与设计稿的偏差

选中标记用字典里的 `check`，稿子是 CheckCircle——图标字典没有 `check-circle`
这个名字，且本仓另两处单选面板用的也是 `check`。要加这个名字属图标字典的
改动，另开 PR。

## 12.19.0 — 2026-09-24

面板行补齐 Figma 的资源与账单版面（minor：新增槽位，无删改；`ShellPanelMeterRow`
版面重排）。

### `ShellPanelMeterRow`

- 新增 `description`（副行）、`value`（读数）、`unit`（单位）。
- **版面重排为两栏**：左边「这是什么」（标签 + 副行），右边「现在多少」
  （读数 + 进度条 + 用量文案）。进度条从横跨整行改为落在右栏。

  **升级影响**：只传 `{icon,label,valueLabel,percent}` 的既有调用点不会编译
  失败，但**画出来会变**——`valueLabel` 从条的右上方移到条的**下方**，条宽从整行
  变为右半栏。本仓内只有预览面用到它。

  **为什么这么排**：同一段里相邻的几条（额度、存储）右缘对齐、长度可比，扫一眼
  就知道哪个更满。横跨整行时每条的起点被各自标签的长度推着走，比不了。

- 右栏取一半宽而不是定死 160px：面板宽度本身有 sm/md/lg 三档，写死的块在窄档里
  会把标签挤没。

### `ShellPanelRow`

- 新增 `unit`——值的单位单独成槽位。拼进 `value` 就只能同色同字重，而单位本来
  该比数值轻一档。
- 新增 `valueTone`：`"muted"`（默认，即原行为）与 `"strong"`（primary-muted
  底色的数值块，用在账户余额、本月账单这类「这一行就是为了让人看这个数」的行）。
  不做成语义色档——这里区分的是**轻重**不是吉凶。

### 与设计稿的两处偏差

- 副行颜色取 `muted-foreground`，设计稿是 `content-tertiary`。改成后者会让
  `ShellPanelRow.description` 与本件的副行在同一面板里出现两种灰，先统一到既有
  的那一种。
- 图标与文字的间距沿用面板既有的 `ROW_GAP`，设计稿是 24px。面板内各行的文字
  必须起于同一列，为这两类行单独放宽会破坏纵向对齐。

两处都留给设计侧裁定。

## 12.18.0 — 2026-09-24

跟随 design-ui 9.12.0：`InputOTP` 新增 `size="lg"` 档（minor：纯增量）。

伞包自身无改动，再导出面不变（design-ui 258 + design-tokens 7）。新增的
`InputOTPSize` 是类型导出，与既有的 `ToggleSize` / `ButtonSize` 一样走
`export *`，不进再导出清单。

## 12.12.0 — 2026-09-16

默认标识资产对消费方开放（minor：纯增量）。

- `exports` 新增 `./assets/*` 子路径。`files` 里一直有 `assets`，但 `exports` 没列它
  ——Node 的 exports 一旦声明，未列出的子路径就被封死。实测过：改之前
  `require.resolve("@vxture/design-system/assets/icons/tenant-default.png")` 是
  `MODULE_NOT_FOUND`，改之后解析得到。**资产随包发出去不等于消费方取得到**，
  monorepo 里读文件系统看得见，装完就断。
- `assets/icons/tenant-default.png` 换成 512×512（原 128×128）。详情页要按原图看——
  运营得看清用户传的到底是什么（违规图片审核），128 在那个位置会糊。

默认标识由 DS 统一供图（owner 2026-09-16）：全平台与智能体用同一份，不各门户
各放一张。个人租户与组织租户**共用**这一张（图标那边仍是 `building-office` /
`buildings` 两档分形，默认标识不跟着分）；用户默认用 `avatar-default.png`（256×256）。

---

## 12.11.0 — 2026-09-16

伞包跟随 design-ui 9.8.0（minor）：图标字典新增 `building-office`、`building-apartment`、
`city`、`hospital`、`house-line` 五个名字。明细见 design-ui 9.8.0。

---

## 12.10.3 — 2026-09-16

伞包跟随 design-ui 9.7.3（minor）：`TableTitleCell` 新增 `layout="stacked"` 一档，
纵向居中、主行不加字重，收编各门户手写的「两条并列信息」格子。明细见 design-ui 9.7.3。

---

## 12.10.2 — 2026-09-16

伞包跟随 design-ui 9.7.2（patch）：`DialogForm` 打开时跳过用 `disabled` 禁用的组合框，焦点
落到第一个可编辑字段。明细见 design-ui 9.7.2。

---

## 12.10.1 — 2026-09-15

伞包跟随 design-ui 9.7.1（patch）：`DialogForm` 打开时焦点落到第一个字段控件，不再落到
`FieldLabel` 的帮助 icon 上把说明气泡弹开。明细见 design-ui 9.7.1。

---

## 12.10.0 — 2026-09-15

伞包跟随 design-ui 9.7.0（minor）：新件 `FilterPopover` / `countFilterValue`；
`FilterPanel` / `FilterPanelTrigger` 弃用（下一个 major 删除）。明细见 design-ui 9.7.0。

消费方：opera 能力管理页面把左侧抽屉换成「工具行下拉框 + 更多筛选气泡」；平台侧守卫禁止
新用 `FilterPanel`。

---

## 12.9.0 — 2026-09-15

伞包跟随 design-ui 9.6.0（minor，纯增量）：`FieldLabel` 的 `required` / `hint`、
`FieldGroup columns={2}` 与 `Field span="full"`、新件 `FilterPanel` /
`FilterPanelTrigger` / `countFilterPanelValue`。明细见 design-ui 的 9.6.0。

消费方要点：opera 能力管理四页是第一批（弹窗收敛到 `DialogForm size="sm" | "lg" | "xl"`、
详情抽屉 `width="lg"`、筛选收进左侧面板），平台侧由 `ds/overlay-panel-preset` 守卫
锁住新增。

---

## 12.3.0 — 2026-09-09

`ShellSidebarNav` 的导航项新增可选 `trailingIcon`（minor，纯增量：不传即原行为）。

- `ShellNavItem.trailingIcon` → 行尾渲染一个**纯指示图标**，只画不可点。用途是标出
  这一项的**去向语义**：整行本身就是那个跳转（`href` 指向站外），需要一个记号让人
  在点之前知道会离开当前站点。与 `PanelItem.trailingIcon` 同名同义，不发明新概念。
- **与 `external` 的区别**：`external` 是第二个目的地（点行去 A、点图标去 B，两个都能点）；
  `trailingIcon` 只有一个目的地，图标是它的标记。两个都传时以 `external` 为准——
  它是可交互的那个，把可点的东西挤掉更糟。
- 图标**放在主链接内部**：它不可点，不构成「链接里的链接」。（`external` 那个不同，
  必须在外面。）收起态不渲染。

消费方裁定（console，2026-09-09）：「模型服务 / 技能工具」两项不再提供 console 页面，
整行直接跳文档站——于是行尾那个可点的外链图标成了多余的第二个去处，换成指示图标。

`tests/shell-sidebar-external.test.tsx` 增 5 条：不新增第二个链接、图标在主链接内部、
`external` 在场时不渲染、收起态不渲染、不传即原行为。

---

## 12.2.0 — 2026-09-08

`ShellSidebarNav` 的导航项新增可选 `external` 槽位（minor，纯增量：不传即原行为，
五个门户都不受影响）。

- `ShellNavItem.external = { href, label }` → 行尾渲染一个外链图标，**独立于主链接**：
  点行本身仍走 `href`（应用内），点图标去 `external.href`（新标签页，`noopener noreferrer`）。
- **为什么必须在主链接之外**：嵌进去就是「链接套链接」，HTML 不允许、浏览器会拆开，
  点击落到外层——图标看着在、点了却去了应用内页面。实现上是外套一层 `relative`
  容器、图标绝对定位压右侧；主链接同时加 `pr-2xl`，免得长标签钻到图标底下。
- `label` 必给：纯图标链接没有可访问名，对读屏器等于隐身。
- 收起态不渲染（只剩图标，没有位置放第二个可点区）。

用途是把「读物」引到它该在的渠道而不占掉导航位——console 的「模型服务 / 技能工具」
在工作台只答「你有什么」，能力说明与用法在文档站（消费方裁定 2026-09-08）。

`tests/shell-sidebar-external.test.tsx` 7 条：两个链接并存、外链不在主链接内部、
target/rel、可访问名、右侧留位、收起态不渲染、以及「不传 external 时只有一个链接」。

---

## 12.1.0 — 2026-09-07

跟随 `@vxture/design-ui@9.1.0`（minor）。

- 新增 `align: "numeric"`，与 `money` 并列：数值列分三种（金额 / 纯数值 / 短数字），
  前两者走同一个定宽块，第三种走默认居中。向后兼容。见 ui 的 9.1.0 条目。

---

## 12.0.1 — 2026-09-07

跟随 `@vxture/design-ui@9.0.1`（patch）：`money` 档块宽 16ch → 12ch。见 ui 的 9.0.1。

---

## 12.0.0 — 2026-09-07

跟随 `@vxture/design-ui@9.0.0`（**major**）。

- 破坏性：`DataTableAlign` 的 `"numeric"` 改名 `"money"`，纯数字改走默认居中。
  另有金额档定稿（16ch 定宽块、居中不贴右缘）、操作列回定宽、排序标换上下一对箭头。
  逐条见 ui 的 9.0.0 条目。

---

## 11.0.1 — 2026-09-07

跟随 `@vxture/design-ui@8.0.1`（patch）。

- `TableTitleCell` 缺省字号档从 16/14 回到 14/12，主信息改加粗。8.0.0 的 16/14
  实测顶开本件钉死的行高、把表格行距撑得过分，当天撤回。见 ui 的 8.0.1 条目。

---

## 11.0.0 — 2026-09-07

跟随 `@vxture/design-ui@8.0.0`（**major**）。

- 表格列对齐规范重订。破坏性的一条：`DataTableColumn.align` 默认值从一律 `left`
  改为随位置（首列 `left`、其余 `center`），没有显式写 `align` 的非首列会变成居中。
  另有新增的 `align:"numeric"`、操作列改右对齐、`TableTitleCell` 字号提到 16/14。
  逐条见 ui 的 8.0.0 条目。

---

## 10.2.0 — 2026-09-07

跟随 `@vxture/design-ui@7.2.0`（minor）。

- `BarChart` 补上纵轴刻度、读数条与键盘可达；调用方无需改动。见 ui 的 7.2.0 条目。

---

## 10.1.0 — 2026-09-05

（回填：本条与下面三条当时随发布漏写，2026-09-07 按各自的发布提交补上。）

跟随 `@vxture/design-ui@7.1.0`（minor：新增具名导出 `EditableRow`）。见 ui 的 7.1.0 条目。

---

## 10.0.3 — 2026-09-02

跟随 `@vxture/design-ui@7.0.3`：`NativeSelect` 右内距回 `pr-xl`（撤回 10.0.1 的判断）。

---

## 10.0.2 — 2026-09-02

跟随 `@vxture/design-ui@7.0.2`：FilterBar 右段控件压小一档字号。

---

## 10.0.1 — 2026-09-02

跟随 `@vxture/design-ui@7.0.1`：`NativeSelect` 右内距加到 `pr-2xl`。**已被 10.0.3 撤回。**

---

## 10.0.0 — 2026-08-28

跟随 `@vxture/design-tokens@3.0.0` 与 `@vxture/design-ui@7.0.0`（major）。

- shell 层 10 处 `gap-none` / `px-none` / `right-none` / `bottom-none` 改写为 `-0`。
- 消费方升级要做的：搜 `-none` 结尾的间距工具类（`p-none` / `gap-none` /
  `pt-none` / `inset-x-none` …）改成 `-0`。**不改也不报错**——类名不再产出，间距
  静默回落到该元素的继承值，这正是本次要根除的那类失效。

## 9.0.8 — 2026-08-27

修一处外壳的视觉重复，跟随 `@vxture/design-ui` 6.0.8（patch，050 §2）。

- **修复：`ShellUserMenu` 的认证贴标画了两个对勾。**

  `StatusBadge` 的前导图标**缺省就随语气来**（它的文件头：「图标缺省随语气取自
  `toneIcons`，因此不必每处各配一张」），`success` 语气自带圆形对勾。这里在它
  之外又显式画了一个 `<Icon name="check" />`，于是「已认证」前面并排两个勾。

  改法：删掉多画的那一个，语气图标照旧。**调用方无需改动**——`statusTag.verified`
  的含义不变，仍是「上成功语气 + 带一个前导对勾」，只是现在真的只有一个。

- 跟随 design-ui 6.0.8：`Progress` 现在会把取值报给读屏器。伞包里 `ShellPanelMeterRow`
  的用量条因此从「正在忙」变成「已完成 N%」，**调用方无需改动**。详见 design-ui 6.0.8。

- 文档订正：`ShellSidebarNav` 的 `labels` 注释此前写「默认值是中文」，而
  `DEFAULT_LABELS` 一直是英文（提炼进本仓时一并去了业务语言）。注释按实际改正。

- 新增伞包用例 149 条：`ShellPanel` 55 / `ShellSidebarNav` 45 /
  `ShellChrome` 的三个弹层件 49。

## 9.0.7 — 2026-08-26

跟随 `@vxture/design-ui` 6.0.7（patch，050 §2）。

- `InputOTPSlot` 脱离 `<InputOTP>` 单独渲染不再抛 `TypeError`。调用方无需改动
  ——正常用法（格子放在 `<InputOTP>` 里）此前此后都一样。详见 design-ui 6.0.7。

## 9.0.6 — 2026-08-26

跟随 `@vxture/design-ui` 6.0.6（patch，050 §2「改 provider」）。

- **`FullscreenProvider`：从锁滚动的面板切到不锁的面板，退出后页面不再卡住。**
  一页多个可全屏面板时才走得到（`toggle` 换 id 是切换不是退出），症状是
  「关掉全屏以后整页滚不动」。调用方无需改动。详见 design-ui 6.0.6。

## 9.0.5 — 2026-08-26

跟随 `@vxture/design-ui` 6.0.5（patch，050 §2）。

- `Toast` 的通知 id 换成单调计数器，消除同毫秒连发时的 React key 碰撞。
  调用方无需改动——`toast()` 的签名与返回值类型不变，id 一如既往是不透明字符串。
  详见 design-ui 6.0.5。

## 9.0.4 — 2026-08-26

跟随 `@vxture/design-ui` 6.0.4（patch，050 §2「改 provider」）。

- `FullscreenProvider` 的卸载清理不再在每次进出全屏时误触发；原生模式退出不再
  重复调用 `exitFullscreen()`。详见 design-ui 6.0.4。

## 9.0.3 - 2026-08-26

跟随 design-ui 6.0.3（patch 传导，050 §2），tokens 不变。

- **`EntryCard` 只给 `onClick` 不给 `href` 时键盘进不去**：`<a>` 无 `href` 就没有
  角色、不在 Tab 序里，而卡一直摆着可点的外观。现在按「能不能点」分三形态；
  不可点的卡也不再画成可点的样子。详见 design-ui 6.0.3。

## 9.0.2 - 2026-08-26

跟随 design-ui 6.0.2（patch 传导，050 §2），tokens 不变。

- **`MetricListCard` 上键盘按不到行操作**：卡的 onKeyDown 对任何冒泡上来的
  Enter/Space 都响应，掐掉内层按钮的激活并触发整卡。鼠标路径一直是对的，这个洞
  只在键盘上存在。详见 design-ui 6.0.2。
- 文档更正：`AlertDialog` 的 Esc 关得掉（外点不关），头注与 03 §1 原先都写错了。

## 9.0.1 - 2026-08-26

跟随 design-ui 6.0.1（patch 传导，050 §2），tokens 不变。

- **`Drawer` 的宽度挡位一直是死的**：传 sm/md/lg 没有任何效果，一律渲染成
  `w-full max-w-panel-lg`。挡位类名排在 `w-full` 之前，被 tailwind-merge
  静默丢掉。详见 design-ui 6.0.1。

## 9.0.0 - 2026-08-25

跟随 design-ui 6.0.0（major 传导，050 §2「下层的 major 会向上传导」），tokens 不变。

- **`variant="destructive"` 的 `Button` / `ActionButton` 必须写 `confirmExempt`**，
  补上破坏性确认契约的最后一个载体。此前判别联合只管 `ActionMenuItem` 与
  `BulkActionBarItem`，够不到裸的红按钮——`grep confirmExempt` 因此会把只有裸红
  按钮的产品报成「干净」，清单不完整就不能当清单用。
- **新增公开入口 `DestructiveButton`**（composite）：「Button + ConfirmDestructive」
  的固定组合，要拦的红按钮用它。分工是被守卫逼出来的：base 的 `Button` 在
  server-safe 子集里（`MetricCard` 引它），让它引 `ConfirmDestructive` 会把 Radix
  AlertDialog 的 `createContext` 拖进 `/server` 入口、在 react-server 下崩——能弹
  模态的 base 原语就不是 base 原语。
- `variant="destructive-strong"` 不要求：它是落锤档，要求落锤自己再确认是循环。
- 清点口径回到一条：`grep -rn confirmExempt portals/`。
- 详见 design-ui 6.0.0 更新日志。

## 8.0.0 - 2026-08-25

跟随 design-ui 5.0.0（major 传导，050 §2「下层的 major 会向上传导」），tokens 不变。

- **默认文案全部由中文改为英文托底**（83 处 / 20 个文件，含伞包 shell 层的
  `ShellChrome` / `ShellLauncher` / `ShellSearchBox` / `ShellSidebarNav`）。类型
  零改动，**不会编译失败**——但每个消费方的界面都会变。
- **判据：托底，不是产品语言。** 所有应用都应当传参，中文单语的产品也不例外；
  英文默认值出现在生产界面上说明有人忘了传，不是一种受支持的配置。托底之所以
  必须是英文：DS 不知道消费方说什么语言，件内写中文就是替某一个产品做了语言选择。
- **这一版之后件完全兼容 i18n**：任何一处渲染文字都换得掉，含 `aria-label` 与
  `sr-only`。但兼容 i18n 不等于承担 i18n——DS 仍然没有 locale 上下文，翻译在
  调用点。
- `ConfirmDestructive.titleTemplate` 默认值改为 `"{verb} {target}?"`；
  `BulkActionBar` 的 `selectionTemplate` 与 `noun` 一并改（语序和量词是同一句话
  的两半）。
- 守卫 `check-i18n-seam.mjs` 换成二值判据：剥掉注释后不许出现中日韩字符或全角
  标点。注释不受此限。
- 05 §3.1 重写，写明「英文是基准语」的判据与三档收法。
- 详见 design-ui 5.0.0 更新日志。

## 7.2.0 - 2026-08-25

跟随 design-ui 4.2.0（minor 传导，050 §2），tokens 不变。全部向后兼容。

- **7 个件补上文案覆盖出口**（`DataTable` / `BulkActionBar` / `Pagination` /
  `Toast` / `Drawer` / `Banner` / `DialogForm`，共 15 处）。此前这些中文写死在
  组件里、调用方覆盖不掉，其中 `DataTable` 的「操作」是可见表头，
  `BulkActionBar` 的「已选择 {count} {noun}」把中文语序也焊了进去。
- **新增守卫 `check-i18n-seam.mjs`**，已进 `pnpm guardrails`：组件内的中文必须
  有覆盖出口（形参默认值 / `DEFAULT_*` 常量 / `??` 兜底 / 带理由的豁免）。当前
  代码零违规，对 7.1.0 的代码精确报出那 15 处。
- 05 新增 §3.1，写明三档收法：一两条走独立 prop、三条以上走 `labels` 对象、
  拼接出来的句子收**模板**不收词（语序是语法，不是词汇）。
- 留出口不等于做 i18n：DS 没有也不打算有 locale 上下文。
- 详见 design-ui 4.2.0 更新日志。

## 7.1.0 - 2026-08-25

跟随 design-ui 4.1.0（minor 传导，050 §2），tokens 不变。全部向后兼容。

- **`ConfirmDestructive` 新增 `titleTemplate`**（默认 `"{verb}{target}？"`）：
  7.0.0 的件直接拼中文语序，英文下渲染成 `Deletemodel service？` 且覆盖不掉——
  一个门户说什么语言是产品的决定，DS 本就不该握着。同时补 `pendingLabel` /
  `blockedHint` 两个漏开口子的文案 prop。
- **`DestructivePrecondition` 新增 `unknown?: boolean` / `note?: string`**：
  `met` 仍是唯一门闩（放不放行由调用方判），`unknown` 只管把「查不到」和「确认
  没满足」在视觉上分开。少了它 `met: false` 会让界面说假话。
- **勘误**：7.0.0 称 `grep -rn confirmExempt` 给出不设防红色动作的完整清单，
  这是错的——契约够不到裸 `<Button variant="destructive">`。正确口径见 03 §3。
- 预览面新增 `ConfirmStepUp`：确认之后叠一道 step-up 的形态，验两层模态的焦点
  陷阱。DS 不建模 step-up，接缝是 `onConfirm` 返回的 Promise。
- 详见 design-ui 4.1.0 更新日志。

## 7.0.0 - 2026-08-25

跟随 design-ui 4.0.0（major 传导，050 §2「下层的 major 会向上传导」），tokens 不变。

- **`danger` 从视觉开关变成带拦截的契约。** `ActionMenuItem` /
  `BulkActionBarItem` 收为判别联合：`danger: true` 必须给 `confirm`
  （`DestructiveConfirm` 契约，由 DS 弹确认框）或写明 `confirmExempt` 理由。
  所有现存的 `danger: true` 调用点会编译失败——这是本版的目的。
- **新增公开入口 `ConfirmDestructive`**（含 `DestructiveConfirm` /
  `DestructivePrecondition` 类型）：破坏性确认件，把 03 §3 与 05 §46 两条散文
  判据变成必填参数；`preconditions` 带 `met`，未满足即禁用确认钮。
- 迁移写法与豁免规则详见 design-ui 4.0.0 更新日志。

## 6.5.1 - 2026-08-24

跟随 design-ui 3.2.1（patch 传导，050 §2），tokens 不变。

- `DialogForm` 字段区滚动上限 60vh → 70vh（xl 双栏表单在常见视口整表可见）。

## 6.5.0 - 2026-08-24

跟随 design-ui 3.2.0（minor 传导，050 §2），tokens 不变。

- `ActionMenu` 锁死修复：菜单开出的 Dialog 关闭后整页 `pointer-events: none`
  残留（Radix 模态菜单与模态对话框的 body 锁竞争），菜单改非模态后消除。
- `DialogForm` 新增 `xl` 尺寸档（`max-w-panel-xl`，双栏表单）；页脚上方加
  分割线——对话框骨架定稿为「标题 / 内容区 / 分割线 / 操作区下对齐」。
- 详见 design-ui 3.2.0 更新日志。

## 6.4.3 - 2026-08-22

修 `repository.url` 的 scheme 前缀（patch，050 §4）。

- GitHub Packages 的「Repository source」校验只认裸的 `https://github.com/OWNER/REPO.git`，
  `git+https://...` 会被当成非 GitHub 来源，判定为无法校验。去掉 `git+` 前缀，
  `type`/`directory` 不变。

## 6.4.2 - 2026-08-21

补 `package.json` 的 `repository` 字段（patch，050 §4）。

- GitHub Packages 的「Repository source」是直接读 `package.json` 的 `repository`
  字段渲染的，不是按实际发布来源自动判定——本包此前一直没有这个字段，包设置页
  因此显示归属有误。补上 `repository`，指向 `vxture/vxture-design`。

## 6.4.1 - 2026-08-21

重新建立本包的可发布状态（patch，050 §4 / issue #1）。产物内容与 6.4.0 一致，
版本号 +1 仅为解除发布流水线的历史阻塞。

## 6.4.0 - 2026-08-21

### Fixed

- **发布包的 `@source` 指向了不发布的目录**。
  `src/styles/globals.css` 里两条 `@source` 指向 `../../../design-ui/src` 与
  `../components`,而两个包的 `files` 只发 `dist`(design-system 另发 `src/styles`,
  不含 `src/components`)——从 registry 装完之后两个目标都不存在。改指 `dist/`,
  两种安装形态下都解析得到。

  代价在于它**不报错**:变量注册成功、手写 CSS 层照常抵达、组件 DOM 正确,但它们
  身上每一个工具类都不产出,页面渲染成一片灰。症状与「根本没写 `@source`」完全一致,
  极难从现象倒推。它只在 monorepo 里通,因为工作区包是软链到完整签出的。

  接入方从此不需要写任何 `@source`,也不需要在 Tailwind config 里解析包路径。

### Changed (类型面收窄,消费方可能需要改 import)

- **`/server` 的类型面收窄到等于运行时面**。
  `src/server.ts` 里的 `export type * from "@vxture/design-ui"` 看着是安全的,
  但 tsup 的 dts rollup 会擦掉 `type` 修饰符,产出 `export * from '@vxture/design-ui'`
  ——282 个客户端组件名同时落进 `.d.ts` 的**值空间**,而 `server.mjs` 运行时只有 27 个。

  后果是消费方能写出 `import { Button } from "@vxture/design-system/server"`:
  tsc 零错误、构建全绿、渲染时 `Button === undefined`。**类型系统主动为错误写法背书**,
  且只在那条渲染路径被走到时才炸,藏在条件分支里就可能一路到生产。

  按 SemVer 这是类型面的移除,故走 minor 而非 patch:若你此前从 `/server` 取过
  客户端组件的**类型**(如 `import type { ButtonProps } from "@vxture/design-system/server"`),
  改从主入口取即可——客户端组件有哪些,本就是主入口的类型该说的事。取**值**的写法
  在运行时一直是坏的,这次只是让它在编译期就红。

### Added

- `docs/07-consumption-pitfalls.md`:接入陷阱清单,只收「接上去不报错、构建全绿、
  但结果是错的」这一类——T2 语义层无前缀导致的 token 撞名(608 个无前缀名,18 个单段短名)、
  暗色走 `.dark` 而非 `prefers-color-scheme`、`/server` 子集边界、`@source` 现状。
  随包发布(`files` 含 `docs`),接入方装完就能读到。

- 守卫 `check-packed-consumability.mjs`:按 **registry 安装形态** 验三包可消费。
  向 `npm pack --dry-run --json` 要真实发布集(不自己解释 `files` 字段)、按
  `node_modules/@vxture/*` 铺树并接上依赖,然后断言三件事:`@source`/`@import` 目标
  在包里、`@source` 目标里真扫得到工具类(路径对 ≠ 内容对)、`/server` 的类型面
  不宽于运行时面。已接入 CI 与发布流水线,并经反向验证——把上面两条缺陷分别退回去,
  守卫确实报错(`@source` 两个目标失联;`/server` 多出 225 个幽灵值导出)。

  这类缺陷的共同形状是:**monorepo 里永远测不出来,只有消费方会撞上**。
  这条守卫补的就是这个盲区。

## 6.3.1 — 2026-08-21

跟随 design-ui 3.1.1（修 bug，属 patch）。

- 伞包的 `@vxture/design-system/server` 转发同样受益：此前它转发的是一条在
  react-server 下不可求值的链路，现已通过 `--conditions react-server` 实测
  （27 个导出全部可求值）。
- 无 API 变化。发布流水线新增「`/server` 入口 react-server 可求值」验收关卡。

## 6.3.0 — 2026-08-21

跟随 design-tokens 2.2.0（新增具名导出属 minor，050 §2）。

- **新增具名导出：`THEME_CONSTANTS` / `PREFERENCE_CONSTANTS`**（转发自
  design-tokens 2.2.0）。公开入口快照已同步。
- **移除对外部通用包的依赖。** 主题/偏好契约键迁入 design-tokens 后，设计
  三包不再依赖任何业务包——**设计系统自此是自足单元**，可独立发布，
  外部消费者安装时也不再拖入无关依赖。
- 无 API 行为变化：ThemeProvider / themeBootstrapScript / fontSizePreference 的
  取值与键逐字不变，仅导入来源由 shared 改为 design-tokens。
- **API 收窄（shell 语言切换）**：`LocaleSelectOption.locale` 与
  `onLocaleChange` 的参数由平台的 `Locale` 联合类型放宽为 `string`——**设计包
  不拥有平台的语言目录**，支持哪些语言是业务事实，应由消费方经 `options` /
  `localeOptions` 给出。随之 `DEFAULT_LOCALE_OPTIONS` 缺省为空数组（原先内置
  `SUPPORTED_LOCALES`）。
  **消费方须在边界处收窄回自己的 Locale**，例如
  `onLocaleChange={(next) => fn(next as Locale)}`；website / opera 本就显式传
  options，accounts 的默认选项已改由该门户自行按平台目录构造。
- `ShellThemePreference` 改用本包 `ThemeMode`（与原 `Theme | "system"` 取值
  等价，行为不变）。

## 6.2.0 — 2026-08-21

跟随 design-ui 3.1.0（新增组件向上传导为伞包 minor，050 §2）。

- **新增具名导出：`BarChart` / `BarChartProps` / `BarChartDatum`**（柱状图，
  DS 首件数据可视化原语）。具名再导出清单已随生成器重生成，公开入口快照同步。
- 转发 design-ui 3.1.0 的 DataTable 操作列 min-width 修订（无 API 变化）。

## 6.1.0 — 2026-08-20

发布产物修复 + 一个 server-safe 追加（外部消费方均命中）：

- **修复：发布产物在 Next 15 外部消费仓无法编译。** tsup 默认把 dependencies
  当 external，index 产物里保留 `export * from "@vxture/design-ui|design-tokens"`，
  叠加整包注入的 `"use client"` 后被 next-flight-loader 在 server/client 边界
  硬拒（"unsupported to use export _ in a client boundary"）。workspace 源码
  消费不受影响，所以平台 portals 从未暴露此缺陷。修法：`noExternal` 打平内部
  两包，export _ 展开为具名导出（index 现为 281 个具名导出、banner 恰一处）。
  两包仍留在 dependencies（类型转发 + css 子入口）。
- **新增：`/server` 导出 `themeBootstrapScript`。** 纯字符串、天然 server-safe，
  唯一消费场景就是 server 布局的 <head>（首帧前同步主题）；此前只从客户端
  barrel 导出，server 组件构造性拿不到。additive，故按 minor。

消费方指引：升级后「伞包只能从 client 模块导入」的临时限制解除；server 布局
取启动脚本请改用 `import { themeBootstrapScript } from
"@vxture/design-system/server"`。

---

## 6.0.0 — 2026-08-18

DS 治理批次收口：2026-08-18 全面审查（报告存档）+ shell-template 退役战役（八个 PR
当日走完）。判据「DS 只收通用、无业务含义的件」全面落地；下层 design-ui 3.0.0
major 向上传导，伞包按 major 处理。

**外部消费方迁移总表**（从 `5.0.0` 升级）：

| 变更                                                                     | 消费方要做的                                                                           |
| ------------------------------------------------------------------------ | -------------------------------------------------------------------------------------- |
| 认证族删除（AuthLogin 及 auth.css）                                      | 认证 UI 归 accounts 门户；外部仓自建或参照 accounts 实现                               |
| ai-elements 五件删除（ModelBadge 等）                                    | 已归 agent-studio/varda；AI 会话件从 varda 包取                                        |
| `./styles/{admin,website}-tokens.css` 删除                               | 产品取值桥归各自门户 assets；外部仓自带                                                |
| `./styles/shell-template{,-user-panel}.css` 删除                         | 外壳走 DS 组件 + T2 工具类（opera/console/admin 同款路线）；用户面板走 `ShellUserMenu` |
| `./styles/brands/ruyin.css`、`./styles/fullscreen.css` 删除              | ruyin 品牌由其外部仓自带；fullscreen 样式随 `globals.css` 分发，无需单独引             |
| `DENSITY_PRESETS` 删除                                                   | 密度落地走 `densityClass` + CSS token 重映射，px 预设表从未被运行时读取                |
| `FullscreenContainer` / `FullscreenToggle` / `Portal` 删除（经 ui 传导） | 改用 `FullscreenProvider` + `useFullscreen` / 伞包 `ShellFullscreenToggle`             |

### 💥 Breaking

- 上表七类公开入口/导出删除（各删除的判据与过程详见 2026-08-18 审查报告）。

### ✨ 新增

- **`ShellDock`**（+ `ShellDockMode` / `ShellDockProps`）——工作台停靠面板：外壳
  右缘停靠列（助手、检查器一类伴随内容），narrow 420px / wide clamp(480,46vw,760)
  / full 全屏接管三档。自 shell-template 的 `.assistant` 同值收编，console/admin
  的 Varda 停靠列共用，opera 可复用。
- **`ShellUserMenuAction.danger`**——用户菜单危险动作（登出等）走 destructive
  语气；console/admin/opera 三端登出已接。
- **`::selection` 品牌选区色**入 `globals.css`（brand-100，与原 shell 同值）。
- Dialog `width` 档位、`ShellPanelRow.danger`、T2 `panel-xl`、T1 `radius-full`、
  `font/sans` CJK 系统回退——经下层包传导，见 design-ui 3.0.0 / design-tokens 2.1.0。

---

## 5.0.0 — 2026-08-17

admin → DS 收敛批次收口。major 号在批次开启时已定（删除公开导出属破坏性），按 050 §2.1
批次内不重复决策，故正式版沿用同一个号。

收口判据是那份 PENDING 清单**已空**：`check-component-classes.mjs` 实测 103 个组件全部
重写完成、1116 处类名全部由配方生成、无手写视觉片段、无豁免。此前 `5.0.0-alpha.0`
只发到 dist-tag `alpha`，正式版才回 `latest`。

**外部消费方需要做的 —— 注意跨度比版本号看起来更大。** registry 上此前发布的最新版是
**`2.0.0`**：`2.1.0` 与 `4.0.0` 都写在本文件里，但**从未发布**（`3.0.0` 是重构分支内的
中间态，其变更已并入 4.0.0）。所以从 `^2.0.0` 升到 `5.0.0` 要一次跨过三批变更：

| 版本  | 消费方要做的                                                                     |
| ----- | -------------------------------------------------------------------------------- |
| 2.1.0 | 无（纯新增：`./next` 并行入口与 T1/T2/T3 token 层，无视觉变更）                  |
| 4.0.0 | **移除公开入口 `./next` 与 `./styles/tokens.css`**；拆三包但入口不变，拆包不可见 |
| 5.0.0 | 三个 nav cookie 函数改从 `@vxture/shared` 引入；依赖 TS token 表取值处改用工具类 |

`^2.0.0` 不会自动升上来，这是有意的——major 跨越必须是一次显式决定。

### 💥 Breaking

- **`navCollapsedCookieName` / `readNavCollapsed` / `writeNavCollapsed` 迁出**至
  `@vxture/shared`。侧栏收起状态是 cookie 契约不是视觉件，服务端 layout 要在渲染前
  读到它，留在 DS 会把纯服务端组件拖进 DS 的客户端依赖。仓内三个门户的调用点已全部
  改从 `@vxture/shared` 引入；外部消费方需同样改引入源，行为不变。

### ✨ 新增

- **`ShellNavItem.subLabel?`**——导航项副名，渲染成主名下方一行小字（收起态两行都不
  显）。为中文主名 + 英文代号的双语菜单而加：此前只有单行 `label`，双语要么挤在一行
  括号里、要么只能二选一。**纯增量**——不传时行高与渲染与旧版逐像素一致（`NavItemRow`
  由 `h-control-xl` 改成 `min-h-control-xl`，单行项不受影响），副名在选中态不跟随高亮。
- **`ShellNavSection.brandPosition?`**（`"prefix" | "suffix" | "none"`，缺省
  `"prefix"`）——分组标题里产品代号的染色位置。原 `splitBrandTitle` 只认前缀，
  `模型管理 · Atlas` 这类后置写法会把中文主名当成代号染掉。**不做启发式判断**（"哪段
  像代号"在 `安全审计 · RBAC` 上必然误判），由调用方显式声明；`"none"` 表示整条标题
  不分段。类型同为可选，五个消费方门户不传即旧行为。
- **公开入口** `./styles/admin-tokens.css`（admin 遗留 token 桥，收敛期间的过渡资产）
  与 `./styles/workbench.css`。
- **公开入口** `./styles/website-tokens.css`——website 的同类 token 桥。3d5ef7c 退役
  legacy token 层时 admin 补了桥、website 没有，于是营销页两处同时失效：68 个
  `--vx-website-*` 版面刻度随 `tokens-website.css` 一起删除（`min-height` /
  `grid-template-columns` / `padding` 全部 invalid at computed-value time，栅格塌成
  单列），且 `--color-vx-*` 命名空间的 `@theme` 注册被删，源码里 975 处 `text-vx-*` /
  `bg-vx-*` 共 123 个类名一个都不再产出 CSS。两类失效都不报错。桥恢复这批取值，但
  **不复刻 legacy 色值**：数值色阶挂 T1 对应色族（gray→neutral、error→red、
  success→emerald、warning→amber、info→sky），角色型挂 T2 语义槽，故这批第一次
  跟随暗色模式。与 admin 桥同样是过渡资产，逐族换成 T2 类名后即可缩小消失。
- **公开入口** `./styles/fonts.css`（dd8eea5 自托管字体时引入，此前漏登记）。
- **`FieldTier`**（经 design-ui 再导出）——表单字段的分层容器，把「主字段 / 次要字段」
  的分层从各页手写的 `div` + 间距类收进一件组件，使同类表单在不同页上的疏密一致。
  纯新增导出，不影响任何既有入口。
- **组件** `MetricListCard`、`PanelCard` / `PanelItem` / `PanelList`、`FactList` /
  `LabeledValue`、`LevelMarker`——均从 admin 的重复实现里提炼。
- **浮层宽度梯** `OVERLAY_WIDTHS` 与 `overlayWidthClass` / `overlayMinWidthClass`。
  取名 overlay 而非 control：`--spacing-control-*` 已占用同名命名空间，Tailwind v4 的
  `w-*` 解析顺序会让 `--container-control-*` 被高度档影响掉（实测 `min-w-control-xs`
  解析成 1.5rem 的高度值）。

### 🔧 内部

- `@vxture/design-ui` 新增 `./styles` 子入口，只导出配方层（`interactive` 等纯字符串
  常量）。刻意不并进主入口：伞包用 `export *` 转发主入口，配方进主入口就会成为产品
  可见的公开面，产品侧便能拿它手搓控件——那正是配方层要杜绝的。

---

## 4.0.0 — 2026-08-01

设计系统重构收口。`3.0.0` 是本次重构分支内的中间态，从未发布，其变更并入本条。

### 💥 Breaking

- **拆为三包。** 本包成为**伞包 + 运行时接线**：只持有主题 / 密度 / 字号 provider、
  shell 与 auth，其余转发 `@vxture/design-tokens`（token 两层 CSS）与
  `@vxture/design-ui`（无状态组件层）。**消费方仍只依赖本包**，入口不变，拆包不可见。
  对另两包用精确版本——本包把它们的类型原样 re-export，caret 会在转发边界上产生
  类型不匹配。
- **移除公开入口** `./next`（cva 组件的过渡入口，迁移已完成）、`./styles/tokens.css`
  （迁至 `@vxture/design-tokens/styles/tokens.css`）、`./styles/components.css`。
- **移除 11 张 TS token 表**（`colors` / `spacing` / `typography` / `radius` / `shadow` /
  `gradients` / `motion` / `easing` / `duration` / `animation` / `motionPresets`）。
  它们的 `var()` 目标多数早已不存在，且零消费者。取值的出口是工具类，不是 JS 字符串。
- **色板换为 Tailwind v4 的 oklch / P3**，并收窄到六个色相加品牌色。原先停在 v3 的
  hex，且多出 5 个只为图表各取一档的色相；`chart-2..6` 已改用保留色相，
  **图表配色可辨识度下降**。
- **遗留样式层退役**（155 个文件、约 12.3k 行）。批次开启时有 43 个组件仍依赖其中的
  BEM 类名、当时渲染无样式；**收口时已全部重写完毕**（`check-component-classes.mjs`
  的 PENDING 清单为空，103 个组件 1116 处类名全部由配方生成）。
- **排版规则化。** 行高改取字号档自带的值（display 与品牌标题收紧到 `leading-tight`）；
  字距统一为零，仅 `overline` 因全大写保留放开。原先逐角色写死的 72 个行高里
  有七组同字号不同值，规则化后这类分歧在结构上不可能存在。
- Button 合并：cva 版本取代原实现，`.vx-btn` 随遗留层消失。

### ✨ Added

- `DENSITIES` / `FONT_SIZES` / `densityClass` / `fontSizeClass`，由与 CSS 同一份策略生成。
- 中文排版轴：`:lang(zh)` 自动加大行高，作用于任何角色。
- T1 扩展档：`text-3xs/2xs`、`breakpoint-xs/3xl/4xl/5xl`、`font-brand/cjk`。

### 🛠 Internal

- T1 改为直接读 Tailwind `theme.css` 生成，一致性由构造保证；全部偏离登记在
  `foundation-policy.mjs`，逐条带理由。
- token 输入全部迁入 DS 自有的 `*-policy.mjs`，设计导出文件退役。
- 新增守卫 `lint:design-classes`（组件类名必须真能产出）与两条包依赖方向规则。

---

## 2.1.0 — 2026-07-31

### ✨ Added

- **`@vxture/design-system/next`** —— 按 shadcn 惯例（cva + Radix）重写、只绑 T2 语义层的组件并行入口。首个组件为 `Button`。根入口的既有组件保持不变，消费方可按自身节奏迁移；两处同名导出属预期。
- T1/T2/T3 三层 token 已完整落入 `src/styles/{foundation,semantic,components}`，并通过 `styles/tokens.css` 聚合。本版本尚无组件消费新层，**无视觉变更**。

---

## 2.0.0 — 2026-06-29

外壳样式体系统一 + 旧 console 外壳包下线。**包含一处破坏性变更（删除 `styles/console.css` 入口）**，故升 major。当前外部消费者（多个业务智能体）均在早期开发阶段，影响有限——请按下方迁移建议一次性切齐，避免遗留技术债。

### ⚠️ Breaking

- **删除导出 `@vxture/design-system/styles/console.css`**（及其整包子模块：`console-base / console-shell-layout* / console-shell-chrome* / console-shell-drawer / console-tenant-switcher* / console-assistant / console-responsive`）。
  - 这是模板化之前的旧 console 外壳 CSS（`.vx-shell-*`、`.vx-tenant-switcher__*`、`.vx-assistant-*`、`.vx-appcenter`、`.console-loading` 等），已被新的共享外壳体系取代，平台内部已无人使用。

### ✨ Added

- **`@vxture/design-system/styles/shell-template.css`** —— 共享外壳视觉系统（逐字转写自设计稿的 `.app / .vxh / .sidebar / .assistant / .vela-*` 外壳 chrome + 其 token），console 与 admin 同源消费，是新外壳的唯一来源。
- **`@vxture/design-system/styles/shell-template-user-panel.css`** —— 仅"头像 + 用户下拉菜单"切片（template tokens + `.vxh-*` 用户面板规则，不含全局 reset / 完整外壳 chrome）。供只需要用户菜单、不要整套 app 外壳的应用（如门户/营销站）使用。
- Phosphor 图标字体不内置：宿主应用在 `app/layout.tsx` 用 `<link>` 加载 `@phosphor-icons/web`（外壳用 `ph ph-*` 类）。

### 🔧 Internal（对消费者无影响）

- `src/components/ui/*` 组件文件统一重命名为 PascalCase（如 `page-header.tsx` → `PageHeader.tsx`）。**公共导出符号不变**——`import { Button, PageHeader, … } from "@vxture/design-system"` 照常工作。仅当你绕过公共 `exports`、深路径 import 内部文件时才受影响（不应这样用）。

### 📦 消费者迁移建议（业务智能体）

1. 依赖升到 `^2.0.0`。
2. **若曾 `@import "@vxture/design-system/styles/console.css"`**：
   - 你渲染的是**应用外壳**（header/侧栏/助手三分区）→ 改用 `@vxture/design-system/styles/shell-template.css`，并按需用 `.app / .vxh / .sidebar / .assistant` 类（参考 console/admin portal 的 `layout/template/` 实现）。
   - 你只用了**用户头像下拉菜单** → 改用 `@vxture/design-system/styles/shell-template-user-panel.css`。
   - 你只用了**加载转圈 `.console-loading`** 等零散类 → 这些已随外壳下线移出 DS；请改用 DS 现有基础组件（如 `Skeleton`），或在你的应用内自留极小副本。
3. 组件按符号从包根导入即可，**不要深路径 import 内部文件**（`ui/` 已 PascalCase，公共 API 未变）。
4. 别忘了宿主 `app/layout.tsx` 用 `<link>` 加载 Phosphor 图标字体。

### 验证

- 平台内 console / admin / website 三端构建通过；design-system guardrail 0 violations；已上生产 `develop=beta=main`。
