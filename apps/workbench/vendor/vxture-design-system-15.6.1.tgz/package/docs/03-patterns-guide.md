# 03 模式选用判据

适用版本：**DS 15.6.1** ｜ 更新：2026-11-10

同一件事只有一种画法。选错件不是审美问题，是语义错误。

## 1. 容器：Dialog vs Drawer vs 整页

| 件          | 用在哪                                            | 判据                                                                                                                                                                                    |
| ----------- | ------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Dialog      | 确认、危险操作批准、短表单（DialogForm）          | 打断一下，说完即走                                                                                                                                                                      |
| Drawer      | 详情查看、轻量编辑                                | 列表维持可见；行点击开 Drawer，长内容在 Drawer 承载                                                                                                                                     |
| 整页        | 复杂对象详情、多步流程（Detail/FormPageTemplate） | 对象复杂或流程多步时才离开列表                                                                                                                                                          |
| AlertDialog | 要求用户表态                                      | 无 X 关闭钮、点遮罩不关；**Esc 仍关得掉**（没有键盘出路的模态是键盘陷阱）。不可撤销的落锤给 Action 传 `destructive-strong`。**破坏性确认不要直接用它**，用 `ConfirmDestructive`（§3.1） |

层叠已定好：drawer(400) < modal(500) < popover(600)——模态可从抽屉内唤起，气泡可用在模态内。

## 2. 反馈：Toast vs Banner

判据：**Toast 说"刚才那一下成了没有"，说完就走；Banner 说"这个页面现在处于什么状态"，状态还在就一直看得见**。Banner 不自动消失，`onDismiss` 只在状态可由用户主动接受时才给。

两者 tone 均为共用六档（见 04 §2）；`danger` 档的 Toast 以 `aria-live="assertive"` 播报，其余 polite。

## 3. 危险两档：destructive vs destructive-strong

判据是**数量**：

| 档                           | 用在哪                                 | 为什么                                       |
| ---------------------------- | -------------------------------------- | -------------------------------------------- |
| `destructive`（淡底）        | 入口：列表行删除、菜单危险项、状态徽章 | 一屏可能有十个，实心红会把视觉重量全吸走     |
| `destructive-strong`（实心） | 落锤：确认对话框的提交                 | 一屏只有一个，且按下不可撤销，弱化它是帮倒忙 |

真正的拦截交给二次确认，不靠按钮颜色吓人。DialogForm 的 `danger` 开关即此映射。

**这句话从 design-ui 4.0 起有了载体，不再只是约定。** `ActionMenuItem` /
`BulkActionBarItem` 是判别联合，`danger: true` 必须二选一：

| 写法                          | 含义                                                        |
| ----------------------------- | ----------------------------------------------------------- |
| `confirm: DestructiveConfirm` | 由件自己弹 `ConfirmDestructive`，落锤走 `confirm.onConfirm` |
| `confirmExempt: string`       | 显式豁免，**理由必填**（动作可撤销，或上游已拦过一道）      |

不写确认曾是零成本，现在是编译错误；豁免要写理由，且理由是可 `grep` 的字符串
而不是注释。

**契约覆盖三个载体**（design-ui 6.0 起）：

| 载体                      | 危险档                  | 要求                                                  |
| ------------------------- | ----------------------- | ----------------------------------------------------- |
| `ActionMenuItem`          | `danger: true`          | `confirm` 或 `confirmExempt`                          |
| `BulkActionBarItem`       | `danger: true`          | 同上                                                  |
| `Button` / `ActionButton` | `variant="destructive"` | `confirmExempt`（要拦就换 `DestructiveButton`，见下） |

`variant="destructive-strong"` **不要求**：按上表它是落锤档——确认对话框里的那个
提交按钮。要求落锤自己再确认一次是循环。

于是清点口径回到一条：

```bash
grep -rn "confirmExempt" portals/   # 已声明豁免的红色动作，逐条带理由
```

6.0 之前这条清单是不完整的：判别联合只管两个数据驱动的件，够不到裸的
`<Button variant="destructive">`（accounts 的删 passkey 按钮就落在这个洞里，而
`grep` 会把 accounts 报成干净）。当时的处置是把文档改诚实、给出两条 grep 的口径
——**那让文档对一个洞诚实，并没有把洞补上**，且第二条 grep 是纯人工纪律、没有
任何强制力，正是这套契约一开始要消灭的东西。6.0 把它补上了。

**为什么红按钮分成两件。** base 的 `Button` 只承担类型义务（写明为什么不设防），
拦截由 composite 的 `DestructiveButton` 承担——不是设计洁癖，是 `Button` 在
server-safe 子集里（`MetricCard` 引它），让它引 `ConfirmDestructive` 会把 Radix
AlertDialog 的 `createContext` 拖进 `/server` 入口、在 react-server 下直接崩
（2026-08-25 由 `check-server-entry-safety` 实测抓到）。**能弹模态的 base 原语
就不是 base 原语。**

`DestructiveButton` 不开 `variant`（按定义就是入口档）也不开 `asChild`（渲染
「按钮 + 对话框」两个节点，塞不进 `Slot` 的单子元素约束）。`AlertDialogTrigger
asChild` 这类场合用 `Button` + `confirmExempt`。

## 3.1 破坏性确认：ConfirmDestructive

`AlertDialog` 是强制二选一的**容器**，`ConfirmDestructive` 是「破坏性确认」这个
**契约**——同 `Dialog → DialogForm` 那一步。契约四项：

| 参数            | 作用                                                                                             |
| --------------- | ------------------------------------------------------------------------------------------------ |
| `verb`          | 动作名，必须是动词本身。同时进标题与确认钮——写不出「确定」。默认英文，中文由调用方传             |
| `target`        | 对象。与 verb 一起填进 `titleTemplate`（默认 `"{verb} {target}?"`；中文传 `"{verb}{target}？"`） |
| `consequence`   | 后果一句，**必填**。写不出后果的动作本就不该染红                                                 |
| `preconditions` | `{ label, met }[]`。任一条 `met: false` 即禁用确认钮并标出是哪条                                 |

前置条件带 `met` 而不只是文案：「必须已下线、且没有入口或授权还在引用它」本就是
算出来的结论，只渲染成文字等于把它扔了。未满足就真的拦住——到这一步「红」与
「拦」才是同一个决定。

`onConfirm` 返回 Promise 时件自接「处理中」态：成功才关，失败不关（用户得看见
自己按的那一下没成）；错误重新抛出，DS 不发明错误 UI，要出 Toast 在 `onConfirm`
内部 catch。

## 4. 空与结果：EmptyState vs ResultPage

| 件                 | 用在哪                                  |
| ------------------ | --------------------------------------- |
| EmptyState         | 板块内空态：列表无数据、筛选无匹配      |
| ResultPageTemplate | "整页只说一件事"：提交成功、404、无权限 |

ResultPage 本质是 EmptyState 的整页形态——直接组合它，不重写；语义色只走顶缘 2px 色条，永不填底（整页染色会把"发生了什么"盖成"到处都是红"）。

## 5. 卡片：MetricCard vs EntryCard

判据：**MetricCard 报数，EntryCard 引路**。

| 件         | 特征                                                                                            |
| ---------- | ----------------------------------------------------------------------------------------------- |
| MetricCard | 读数 20px 不用展示体大字（成排出现，36px 会让四张卡各自都在喊）；语气只染顶缘色条与图标，不染底 |
| EntryCard  | 整卡可点；唯一图标带色块底的卡（门牌要比路标醒目）；veil 取 strong 档，hover 染淡品牌色         |

## 6. DataTable 行操作标准

**行操作列 = `align: right` 列 + `ActionMenu`**。触发器形态、危险项配色、分隔位置由 ActionMenu 固定（`danger` + `separatorBefore`），调用方只给 `items` 不给 markup。

DataTable 三态一次定齐：加载出骨架行（撑住高度）、空态出 EmptyState、有数据出行；选择态 `selectedKeys` 受控，与 BulkActionBar 对接。与 Table（markup 族）的分工：DataTable 管三态/排序/选择，Table 族只管 markup。

## 7. 模板五件

模板只定结构与区块占位，零新样式、零文案默认值——"长什么样"在模板，"放什么"永远在产品侧。

| 模板               | 适用场景   | 结构要点                                                                                                                                                                                          |
| ------------------ | ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ListPageTemplate   | 标准列表页 | 页头 → 筛选行 → 批量条 → 表格；列表区三段收紧 `gap-sm`                                                                                                                                            |
| DetailPageTemplate | 对象详情   | 页头 + 主列（Section 阶梯自组）+ 可选右栏摘要；窄屏 aside 塌到主列**之下**（摘要是快照，塌上会把主体挤出首屏）                                                                                    |
| FormPageTemplate   | 整页表单   | **表单区不限宽**（2026-08-12 撤掉原先的 `max-w-content-narrow-lg`）——与列表页在同一侧栏下露出两种内容宽度，读者会当成两套系统；字段多宽由调用方自己用 grid 控制。动作条虚线上边框，可 sticky 粘底 |
| DashboardTemplate  | 工作台     | 指标区 → 入口区 → 其余板块；阅读顺序焊死：先看数、再选路、最后处理事项                                                                                                                            |
| ResultPageTemplate | 整页结果   | 见 §4                                                                                                                                                                                             |

## 7.1 页面 Header 四种视角

顶栏按**页面视角**分四种（owner 2026-09-25，09-26 重排高度与操作组合；Figma Header_website / Header_console_tenant / Header_console_workforce / Header_product）。不做成四个组件：都是 `ShellHeader` 的三个槽位里拼零件，区别只在放哪些零件。示例见 preview「外壳与登录 → PageHeader」。

| 视角             | `ShellHeader` 参数                                        | 左侧（leading）                                                                                                                                                                                                                             | 右侧（trailing）                                                                                                                                                              |
| ---------------- | --------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1 官网           | `layout="centered"` `surface="transparent"` `height="xl"` | `ShellHeaderMark` + `ShellHeaderTitle`（站名）；产品页再加 `ShellHeaderDivider` + `ShellProductTitle`（标识 / 名称 / 类型）                                                                                                                 | 未登录：`ShellHeaderTools`（只给主题 / 语言 / 全屏）+ 注册 / 登录（`Button size="sm"`）；产品页把注册 / 登录换成「官网」；已登录：`ShellHeaderTools`（六件）+ `ShellUserMenu` |
| 2 租户用户工作台 | 全宽 `surface="background"`，高度用缺省 `md`（48px）      | `ShellLauncher` + `ShellHeaderMark` + `ShellHeaderTitle`（平台名 vxture.ai）+ `ShellHeaderDivider` + `ShellScopeButton`（当前租户，不带图标）                                                                                               | `ShellSearchBox` + `ShellAgentButton` + `ShellHeaderTools`（六件）+ `ShellUserMenu`                                                                                           |
| 3 平台管理工作台 | 同 2                                                      | 同 2，标题同为平台名，但**必须带管理员徽标**（`ShellHeaderTitle badge`，实底 `Badge`，上标位）；分隔线后是 `ShellHeaderDomain`（当前域），不放租户选择                                                                                      | 同 2                                                                                                                                                                          |
| 4 单产品视角     | 同 2                                                      | `ShellIconButton icon="sidebar"` + `ShellLauncher` + `ShellHeaderMark` + `ShellHeaderDivider` + `ShellProductTitle`（标识 / 名称 / 类型 / 上标等级，等级用 `StatusBadge size="sm"`）+ `ShellHeaderDivider` + `ShellScopeButton`（当前租户） | 同 2                                                                                                                                                                          |

判据：

- **高度**：工作台三种 48px（`ShellHeader` 缺省 `md`），把纵向空间让给内容；官网 64px（`xl`），它是页面门面。
- **间距**：左 / 中 / 右三组之间、组内零件之间一律 8px（`ShellHeader` 自带 `gap-xs`），不要在零件外再包一层间距。
- **官网不带任何工作属性**：没有九宫格、租户、域名、搜索、智能体。内容居中封顶，与正文同列。
- **工具箱常态透明**：`ShellToolbox` 平时无底，悬停或键盘焦点落进组内时才整组亮底、指针所在的工具再亮一层；不要给它补底色。
- **工具箱用 `ShellHeaderTools`，顺序与交互固定**（owner 2026-09-26）：① 主题（点击切换）② 语言（弹出面板选择）③ 全屏（直接切换）④ 帮助（新标签页，定位到**当前页面**的帮助主题）⑤ 消息（侧边抽屉）⑥ 配置（跳转后台配置）。门户只决定给哪几件：访客给前三件，登录后给全部六件。不要用 `ShellToolbox` 自己排顺序——六个门户各排一遍迟早不一样。
- **两种管理工作台靠徽标与分隔线后的内容区分视角**（标题都是平台名）：租户工作台是「租户用户管理自己」，分隔线后是当前租户（可切换）；平台管理工作台是「平台员工管理平台或全部租户」，标题同为平台名，靠管理员徽标区分，分隔线后是当前管理域。两者同屏出现在截图里要一眼分得开。
- **徽标与等级读作上标**：`ShellHeaderTitle` 的 `badge`、`ShellProductTitle` 的 `tier` 都放在顶端对齐的版位里（徽标 24px、等级 32px），比标题略高——它们是标题的注脚，不是并列的第二个名字。
- **单产品视角的主角是产品**：平台标识退为一个小标，产品标题组居中心位置；侧栏开关在最左；分隔线后是当前租户。
- 域名只在 header 出现一次，侧栏不再重复（`ShellSidebarNav` 的 `domainName` 可省）。

## 7.2 租户与用户身份摘要

`TenantInfoSimple` / `UserInfoSimple` 用于列表和下拉选项中的两行身份摘要：24px 身份图形、名称和一行次级标识（租户 ID / 电话等，由调用方传入）。`TenantInfoOneline` / `UserInfoOneline` 只保留名称，适合紧凑列表及正文内联。四件都不承担选择、跳转或弹层行为，交互由外层列表项/按钮负责；不要将 `ShellPanelHeader` 的 48px 大标识列拿来充当列表摘要。

| 形态                  | 尺寸                                       | 用法                                                                          |
| --------------------- | ------------------------------------------ | ----------------------------------------------------------------------------- |
| `Simple`              | 24px 图形、两行文字                        | 列表/选择器需要同时辨认名称与次级标识                                         |
| `Oneline` `size="md"` | 24px 高、24px 图形                         | 常规单行列表；与 Figma 当前 `_oneline` 默认形态一致                           |
| `Oneline` `size="sm"` | 默认最小 20px 高、16px 图形、4px 内距/间距 | 名称用 `text-label`（默认 14px / 20px），与正文同行；字体放大时高度随行高增长 |

名称被截断时，调用方应给外层可用宽度，并在可访问名称或邻近详情中提供完整身份；图形只是辅助识别，不能单靠头像或图标区分同名主体。用户头像缺失时走 `UserAvatar` 的剪影回退；租户图标可由调用方替换。

## 8. 目录分层

判据一句话：**单件进 base，组合进 composite，零视觉纯排布进 layout，页面骨架进 templates**。"单件"看消费不看构造——StatusBadge 构造上是 Badge 派生，消费上是一个控件，归 base。

| 目录                     | 收什么                      | 判据                                                                                                                                                                                               |
| ------------------------ | --------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `base/`                  | 单件控件 / 元素             | 上游有对应件的结构照上游，取值绑 T2，定制就地做并留痕；按功能五组分子目录：`form/` `display/` `navigation/` `overlay/` `feedback/`，归属以预览面的分组字段为准（同一分类法的两个视图），不新开辩论 |
| `composite/`             | 零业务组合件                | 直接给 props 可用；收录看实据不看设想：须已在多个产品中各自重写过；按功能三组分子目录：`form/` `data/` `structure/`                                                                                |
| `templates/`             | 页面级骨架                  | 只定结构与区块占位，零新样式，纯组合下两层                                                                                                                                                         |
| `layout/`                | container / stack / grid 等 | 无视觉，只管排布（SplitViewLayout / ViewLayout 在此）                                                                                                                                              |
| `ai-elements/`           | AI 界面组件族               | 承载 ai（brand-2）局部品牌色的组件；分类上属组合件，独立成目录因其成族出现                                                                                                                         |
| `@vxture/domain-ui` 槽位 | 带业务归属的共享面板        | **DS 零业务**：StatusBadge 有 tone，没有"订阅已逾期"；业务件归 domain-ui（private，不发布）                                                                                                        |

## 9. 归属类判据速查

| 判据                          | 结论                                                                                                                                                  |
| ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| 板块标题谁出                  | 只由 SectionHeader 一处产出（FilterBar 无 title）                                                                                                     |
| 无选中时也显示的动作          | 属于 FilterBar，不属于 BulkActionBar（count 为 0 时它不存在）                                                                                         |
| 语气（tone）                  | 一律引共用六档 neutral/brand/info/success/warning/danger，只表达严重度不表达业务状态；neutral 默认无图标，其余五档图标随语气（toneIcons），不各处自配 |
| 需要系统选择器 / 表单原生提交 | NativeSelect；否则 Radix Select                                                                                                                       |
| 同形状的分段选择（数字/图标） | SegmentedControl，不再各做一件                                                                                                                        |
| 场景 vs 形状                  | 组件按形状命名复用（SplitViewLayout 不叫 SettingsSplitPage）——同一形状处处成立，绑死场景就要重写                                                      |

### Shell panel rows and account medals (15.0.1)

Single-line panel actions, control rows and medal rows use control-xl (32px).
Preferences and action sections use gap-xs (8px). Medal bases are icon-lg
(24px), with icon-sm (16px) glyphs; unearned slots remain visible in neutral
colors. Rows carrying descriptions keep their natural two-line height.

### 统一语言选择

字段入口的面板与触发字段等宽；图标入口保留独立面板宽度。字段当前值与选项行共用标识、母语名和可选译名结构，标识由调用方的 `flag` 提供，未知语言回退到语言代码。

界面语言入口统一使用 `ShellLocaleSwitcher`。工具栏使用默认 `variant="icon"`；偏好字段使用 `variant="field"`，显示当前语言和展开箭头。`ShellPreferencePanel` 内置相同字段，展开后共用 `LocaleSelectPanel`：语言标记、母语名称、末尾选中勾选。应用通过 `options` 传入平台语言目录，DS 不拥有语言清单。

字段提供本地化 `buttonLabel` 和 `panelLabel`；请求期间可设置 `disabled`。面板打开时聚焦当前项，方向键及 Home/End 移动，Enter/Space 选择，Escape 关闭；选择后关闭并恢复入口焦点。国家、时区、业务内容语言不属于该界面偏好模式。

### Sidebar geometry

Pair `ShellSidebarNav` with `ShellSidebarFrame`. The frame provides the geometry scope; the navigation derives its icon rail from the current responsive collapsed width and density insets. Menu icons and the collapse control keep the same horizontal anchor in expanded and collapsed modes; collapsed group arrows share that anchor. Do not add application padding or centering overrides. At default density, the desktop frame is 64px wide, the icon center is 32px, menu rows are 40px and group rows are 32px. Small-screen frames remain 48px wide. Verify all three density settings and both modes after changing spacing or control tokens.

Sidebar rows use their own layout utilities rather than generic control sizes. Menu/group heights are 40/32px at default density, 36/28px compact and 44/36px comfortable. The collapse button follows the group height. Keep this matrix consistent across supported DS versions when migrating control tokens.

### 顶栏尺寸与号码展示

顶栏图标按钮、头像触发器及搜索框统一为 32px，品牌图形为 24px；这些尺寸不随通用控件尺寸或密度改变。独立工具组使用 `ShellHeaderActions`，组间为 16px（窄屏 8px），组内使用 `ShellIconGroup`，间距为 4px；不要在门户自行定义另一套高度或间距。`PhoneNumber` 只呈现调用方提供的 `callingCode` 与 `number`，区号使用弱化文字色；号码解析、国际区号识别与分组由平台负责。

Header brand words are fixed at 24px, secondary labels at 16px. Header tool glyphs are 16px inside protected 32px controls; groups use zero padding and 4px gaps. Scope triggers use 8px horizontal padding and a 4px content gap, with stable geometry on hover/open. Full-width administration headers share Console insets (`px-lg`, `max-sm:px-md`) across density preferences. Public headers cap their usable width at 1536px, extending beyond the 1472px body measure on wide screens.

Administration header inset parity follows Console: desktop compact/default/comfortable = 12/24/24px; narrow-screen = 8/16/16px. The newer token line has a wider comfortable content inset, so full headers normalize that mode without changing content density.

### Joined list and card view control

Use `ViewModeSwitch` from `@vxture/design-system` for list/card presentation. DS owns the joined outline, outer corners, zero gap, 32px targets and 20px icons. Pass `value`, `onChange`, localized `ariaLabel` and `labels`; use `cardsDisabledReason` to explain an unavailable card view. Clicking the selected view does not clear it. Keep data loading and layout rendering in the application; do not reconstruct the control from separate buttons or override its geometry.
