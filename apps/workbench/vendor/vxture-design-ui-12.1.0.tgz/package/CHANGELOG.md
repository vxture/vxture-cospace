# @vxture/design-ui — 更新日志

发布走 `publish-design-system.yml`（GitHub Packages `npm.pkg.github.com`）。版本规则见
`docs/050-design-system-release.md` §2。

---

## 12.1.0 — 2026-11-10

### Dialog support text and overlay corrections

- Add optional `DialogForm.footerNote` for persistent supporting text before the
  standard footer actions, outside the field scroller. Existing forms retain their
  button order, pending state, and destructive behavior.
- Use the standard square icon button for dialog close controls and size the OTP
  caret to the displayed digits.
- Reserve focus-ring space around scrollable dialog and filter fields without
  changing their alignment.
- Keep native select arrows inside their wrapper and apply the current theme to
  native option backgrounds and text.
- Keep destructive confirmations open on failure, show the error, and prevent
  duplicate submissions while an action is pending.

## 12.0.0 — 2026-10-04

**破坏性**：组件全面迁移到收口后的六族排版角色；`SectionHeaderLevel` 从
`2 | 3 | 4` 收窄为 `2 | 3`。原 level 4 的调用方应重新判断信息结构，提升为
level 3 或改用正文 / 标签语义，不再用第四级标题补密度。

- 单行控件统一为 `xs/sm/md/lg/xl = 16/20/24/28/32px`；默认 Button / Input 为
  `md=24px`。同名档在 Button、Toggle、Badge、SegmentedControl、Tabs 等组件中使用
  同一字号与默认图标尺寸。文字收口为 `xs=10px`、`sm/md=12px`、`lg/xl=14px`；
  图标为 `xs/sm=12px`、`md/lg/xl=16px`。
- Badge 补齐五档并将默认档收为 `sm=20px`；`xs=16px` 用于标题旁短角标。
  `2xl/3xl=40/48px` 只保留为特殊页面 token，不进入通用 Button API。
- `StatusBadge` 图标随五档尺寸同步；`ViewModeSwitch` 采用 Figma 定稿的轻量底槽与
  选中态，并对齐当前单行控件尺寸。

- `EntryCard` 标题从等值的原子组合 `text-sm + font-medium` 改为语义
  `text-label`；默认视觉不变，并会随 Small / Default / Large 字号模式切换。
- 六种语气的缺省图标收口：`neutral` 不再用短横占位，默认无图标；`brand`、
  `info`、`success`、`warning`、`danger` 保留语义图标。StatusBadge 的 `dot`
  与显式图标覆盖继续可用。

**标题阶梯最终校正**：本节覆盖下方 11.0.0 记录的中间方案；历史记录保留用于追溯，
当前实现与迁移一律以这里及 `@vxture/design-system/docs/02-visual-spec.md` 为准。

- 产品界面只保留 `heading-1/2/3`，分别对应 `h1/h2/h3`；`title` 家族已删除，
  `display` 只用于营销、首屏与大号展示。
- `ViewHeader`：`h1 + heading-1`；`SectionHeader` 只保留 level 2–3，分别为
  `h2 + heading-2`、`h3 + heading-3`。
- `DialogTitle`、`AlertDialogTitle`、`Drawer` 标题按 Radix 实际输出统一为
  `h2 + heading-2`；`CardTitle` 为 `h3 + heading-3`。
- 默认字号为 18 / 16 / 14px；Small 为 16 / 14 / 12px，Large 为 20 / 18 / 16px。

## 11.0.0 — 2026-09-26

**破坏性**：标题阶梯重排——level 的数字就是 h 的数字，页头改用页头文本（major）。
owner 2026-09-26：「四级标题样式混乱」「level 与 Hn 错位」「ViewHeader 应该用
header 文本」「每级都有下划线（可显隐）」。

| level                     | 之前               | 现在                                    |
| ------------------------- | ------------------ | --------------------------------------- |
| `ViewHeader`              | h1 · `title-xl` 20 | **level 1**：h1 · `heading-3` 24 品牌体 |
| `SectionHeader` 1         | h1 · `title-lg` 18 | **类型错误（已删除）**                  |
| `SectionHeader` 2（缺省） | h2 · `title-md` 16 | h2 · **`title-lg` 18**                  |
| `SectionHeader` 3         | h3 · `title-sm` 14 | h3 · **`title-md` 16**                  |
| `SectionHeader` 4         | h4 · `label-md` 14 | h4 · `title-sm` 14                      |

- `SectionHeaderLevel` 改为 `2 | 3 | 4`。根因在 token：原先页头也用 `title` 族，
  板块只剩三档，第四级借 `label-md`，与 `title-sm` 取值完全相同，三、四级看不出
  差别。页头改用 `heading-3`（另挂 `font-brand`），`title` 族三档整族留给板块。
- **缺省（不传 level）的板块标题由 16px 变为 18px**，`Section` 同。要保持 16px
  传 `level={3}`；原 `level={3}` 要保持 14px 改传 `level={4}`。
- **每一级都带虚线下边框，可关**：`SectionHeader` 的 `divider` 缺省由「只有
  level 2」改为每一级都开，距离随档收（`pb-md` / `pb-sm` / `pb-xs`）；`ViewHeader`
  新增 `divider`（缺省开）。不要线的地方传 `divider={false}`。
- **一行对齐**：`SectionHeader` 改用 grid——图标 | 标题 | 动作同一行、垂直居中，
  动作靠右（原为图标顶对齐、动作贴底 `self-end`）；描述是第二行、只在标题列下，
  不给就没有这一行、不占空间；无图标时去掉图标列。`ViewHeader` 不变。
- 间距随层级收：图标与标题的列间距 level 2 / 3 / 4 为 `gap-x-md` / `gap-x-sm` /
  `gap-x-xs`（原一律 `gap-lg`）；level 2 描述 `body-md`。
- `PanelCard` 标题改用 level 4（h4 · `title-sm`，字号不变）。
- 迁移见发版说明 §02a。

## 10.4.0 — 2026-09-26

`Badge` 新增 `size`（minor：新增 cva 变体，缺省不变）；`ShellHeader` 槽内、槽间
间距统一为 `gap-xs`。owner 2026-09-26 重排四种页面 Header。

- `Badge size`：`md`（缺省，与此前一致：`control-2xs` 下限、`px-sm`）/ `sm`
  （`control-3xs` 下限 16px、行高 1、`px-2xs`）。`sm` 给挂在标题上的角标用
  （Figma Header_product 的 Pro 等级 46×18，owner：tag 高度要压缩）；`StatusBadge`
  透传。新增导出 `BADGE_SIZES` / `BadgeSize`。与 Figma 的差：实际高 16px，Figma
  18px——18px 没有对应的 token 档，取 Figma 自己标的下限 16px。
- `ShellHeader`：左 / 中 / 右三组之间与组内零件之间都是 8px。

- 之前：左槽 `gap-sm`（10px）、中槽 `gap-sm`、右槽 `gap-2xs`（4px）、槽间
  `gap-md`（16px）。**所有用了 `ShellHeader` 的顶栏间距都会变**，API 不变。
- `height` 的注释写明取档：工作台 `md`（48px，缺省），官网 `xl`（64px）。

## 10.3.0 — 2026-09-25

`ShellHeader` 新增 `layout` 与 `surface`（minor：新增可选 prop，缺省不变）。
owner 2026-09-25：四种页面 Header（官网 / 租户工作台 / 平台管理工作台 / 单产品）。

- `layout`：`full`（缺省，铺满视口）/ `centered`（官网：内容居中封顶
  `max-w-page-2xl`，左右 `px-xl`）。Figma 官网内容宽 1600px 不在容器刻度上，取
  最近的 `page-2xl`（1536px）。
- `surface`：`card`（缺省，白底 + sticky 阴影）/ `background`（与页面同底的浅灰 +
  阴影，Figma 工作台画法）/ `transparent`（无底无影，官网）。
- **缺省值与此前一致**：全宽、白底、sticky 阴影，现有门户顶栏不变。

## 10.2.0 — 2026-09-25

`InputOTP` 新增形态轴 `variant`（minor：新增可选 prop）。owner 2026-09-25，照
Figma 2232:10415 / 2232:10450。

- 尺寸 `size`（md / lg）与形态 `variant`（`joined` 连体 / `separate` 独立方格）
  拆成两根轴。不传 `variant` 时 md 连体、lg 独立，与此前一致。实据：8 位验证码
  按 4-4 分组，md 档也要独立方格，组间「-」。
- **观感变化**：独立方格格间距统一为 `gap-xs`（默认 8px），照 Figma；**lg 此前是
  `gap-md`（16px）**。
- `InputOTPSeparator` 字号跟随档位（md `body-md` / lg `body-xl`）。
- 与 Figma 的偏差：数字字号保持 `body-xl`。Figma 是 24px 常规字重的 Inter，DS 排版
  角色里 24px 只有品牌展示体的 `heading-3`。

## 10.1.0 — 2026-09-25

表单的只读展示（minor：新增件与新档，无删改）。owner 2026-09-25：「既是输入，
也是展示」；上下、左右两种布局都要一行两项、一行三项。

- **新增 `FieldValue`**：`Field` 里控件那一格的展示版。同一套 `Field` /
  `FieldLabel` / `FieldGroup` 把控件换成它就是详情页，编辑态与查看态同一张版面。
  高度与输入框同档（`min-h-control-md`），字号与 `Input` 一致
  （`text-body-lg md:text-body-md`），混排时与输入行对齐；空值显示 `—`
  （`empty` 可换，`0` 不算空）；缺省换行，`truncate` 时单行截断。
- **`FieldGroup` 新增 `columns={3}`**：此前只有 1 / 2。列数与 `Field` 的方向是
  两个独立参数，上下（`vertical`）与左右（`labeled`）都能放进两列、三列。三列
  需要页面级宽度。

## 10.0.0 — 2026-09-25

**破坏性**：每页条数的 `"auto"` 档全面删除（owner 2026-09-25）。

- `PageSizeChoice` 由 `number | "auto"` 收窄为 `number`。写了 `"auto"` 的
  `pageSize` / `pageSizeOptions` / `useListPagination(rows, "auto")` 升级后类型报错，
  改成具体条数即可。
- `Pagination`：删除 `pageSizeAutoLabel`；缺省档位 `["auto", 10, 20, 50, 100]` →
  `[10, 20, 50, 100]`。
- `useListPagination`：删除按可视高度量行高的逻辑；缺省每页条数由 `"auto"` 改为
  **20**。**不传第二个参数的页面不会报错，但每页从「一屏能放几行」变成固定 20 条。**
- `ListCard`：不再输出 `data-list-card` 属性（它只给 auto 的行高测量当探针用）。

同时包含未单独发布的 9.13.0 各项（见下）。

## 9.13.0 — 2026-09-25

新增图标 `check-circle`、`workspace`、`caret-line-left` / `caret-line-right`；
`Pagination` 翻页按钮改为图标（minor：
新增可选 props，无删改）。

### `workspace`

- 工作空间（租户下的一块工作区域），图形是立方体（`CubeIcon`，与 `cube` 同形
  不同义：`cube` 泛指资源 / 包）。放在租户 `buildings` 同一分组。
- 此前范围切换面板的工作空间用的是 `folder`，读起来像「点进去是文件列表」
  （owner 2026-09-25 选定立方体）。各产品统一写 `icon="workspace"`，不再各自挑。

### `check-circle`

- 单选面板的**选中标记**（圆形对勾），首个使用者是 design-system 的
  `ShellScopePanel`。Figma 上的选中标记一直是 CheckCircle，此前字典里没有这个
  名字，只能用细对勾 `check` 顶替。
- 与状态图标 `success` **同形不同义**：`success` 表示「操作成功 / 状态正常」，
  `check-circle` 表示「这一项是当前选中的」。字典按语义取名，同一个图形可以
  服务两个语义（先例：`users` / `role`、`help` / `placeholder`）。

### `caret-line-left` / `caret-line-right`

`|<` / `>|`：到最前 / 到最后。首个使用者是 `Pagination` 的首页 / 末页按钮。与
`chevron-left` / `chevron-right`（`‹` `›`）同属 Phosphor Caret 一族，并排放时
粗细、角度一致。

### `Pagination`：翻页按钮全部改为图标（不用改代码，观感变了）

- 顺序：`|<`（首页）`‹`（上一页）页码 `›`（下一页）`>|`（末页）。图标取字典里
  同一族（Phosphor Caret）的 `caret-line-left` / `chevron-left` / `chevron-right` /
  `caret-line-right`；按钮 `icon-md`，与页码同高、正方形等宽。
- **新增首页 / 末页**两个按钮，以及对应的 `firstLabel` / `lastLabel`（默认
  `First page` / `Last page`）。首页与上一页、末页与下一页同步禁用。
- 按钮不再带可见文字：`previousLabel` / `nextLabel` 以及新的两个名字落在
  `aria-label` 与 `title` 上，读屏器照念、悬停浮出。此前「上一页 / 下一页」
  的文字在中英文下宽度差一倍，把整排页码推来推去。
- 调用方原先传的 `previousLabel` / `nextLabel` 继续生效，无需改动。

## 9.12.0 — 2026-09-24

`InputOTP` 新增 `size` 档（minor：纯增量，默认形态与取值行为一个字不变）。

- **`size="lg"`** —— control-3xl 见方的**独立方格**：每格自带四边框与
  `rounded-xl`，格间留白。用在「整屏只干这一件事」的验证弹窗里。默认档
  `md` 仍是 control-md 的**连体**格子，表单行里与其他控件同高。
- 档位定在 `InputOTP` 根件上、经 context 下发给 `InputOTPGroup` 与
  `InputOTPSlot`（与 `ToggleGroup` 同一机制）——一组格子里混搭两种形态没有
  正当场景，所以不做成每格各传。
- 两档尺寸都走控件刻度（`h-control-md` / `h-control-3xl`），跟随密度三档，
  不写裸像素。
- 新增导出类型 `InputOTPSize`。

**为什么不是改默认**：Figma 里 `InputOTPSlot` **组件本体**是 32px
（`--space-control-md`）、`radius-md`、`position` 编码 first/last 连体语义
——与改动前的 DS 逐项一致。56px 独立方格只出现在两个验证弹窗的**实例覆盖**
上，且那里的尺寸是裸数字（实例只绑了 `--radius-xl`，没有任何尺寸变量）。
按稿改默认等于推翻组件本体去对齐无 token 的覆盖，所以做成新档。

**遗留**：设计稿里格内数字是 Inter Regular **24px**，而 DS 排版角色里 24px 只有
`heading-3`（品牌字 + semibold），没有 sans-regular 的 24px 档。本次取同族最大的
`body-xl`（18px）——与 md 档用 `body-md` 保持同一角色族。要不要补一档 24px 的
body 角色，留给设计侧定。

## 9.8.0 — 2026-09-16

图标字典新增 5 个名字（minor：纯增量，现有名字与形状不变）。

「主体/场所」族（Users & organizations）：

- `building-office` → `BuildingOffice`：带门脸的办公楼。个人租户的主体标识用它；原用的
  `building`（素面窄高单体）在小尺寸下轮廓过于墓碑化，不适合做列表里反复出现的身份图标。
- `building-apartment` → `BuildingApartment`：多层公寓楼。

「地点」族（Time & location，与 `map-pin` 同组）：

- `city` → `City`：城市天际线。
- `hospital` → `Hospital`：医疗机构。
- `house-line` → `HouseLine`：住宅。与已有的 `home`（`House`，导航首页入口）分形：
  一个是入口，一个是居住场所，不是同义别名。

图标总数与分组都由 `ICON_GROUPS` 推导，预览面与 `IconName` 自动跟上，无第二份清单要改。

---

## 9.7.3 — 2026-09-16

`TableTitleCell` 新增 `layout` 一档（minor：纯增量，默认行为不变）。

`inline`（默认，原行为）：图标在左，标题加粗并截断——列表首列的形态。
`stacked`：整格纵向居中，主行在上、辅行在下，都不截断，且**主行不加字重**。

给的是「两条并列信息」那一类列（租户名 / 租户码、方案数 / 套餐数）。admin 在 14 个
文件里手写了 21 处这种格子（2026-09-16 勘查），此前收不进本件正是因为默认档是标题
形态：套上去会把居中改成左起、把并列信息读成标题。

- 回归用例 3 条，含反向对照（默认档仍加粗并截断）。

---

## 9.7.2 — 2026-09-16

`DialogForm` 打开时的焦点补一处漏判（patch）。

9.7.1 只排除了 `aria-disabled` 的组合框。编辑态锁住的组合框是
`<button role="combobox" disabled>`，会被选中；`focus()` 对禁用按钮无效，焦点停在对话框
容器上（opera v0.26.176 编辑产品授权实测：产品 / 入口锁定，焦点没落到「应用 ID」）。

- 选择器同时排除 `disabled` 属性的组合框。
- 回归用例 1 条。

---

## 9.7.1 — 2026-09-15

修 `DialogForm` 打开时的焦点（patch）。

`FieldLabel` 带 `hint` 后，标签里的帮助 icon 是个按钮，排在输入框前面；Radix 默认把焦点
交给第一个可 Tab 元素，Tooltip 随焦点弹开——对话框一打开就挂着一条说明气泡（opera
v0.26.174 线上实测，签发 API Key 弹窗）。

- `DialogForm` 接管 `onOpenAutoFocus`：焦点落到字段区里第一个未禁用的
  input / select / textarea / combobox。
- 字段区没有控件（确认、结果展示）时不干预，照旧走 Radix 默认。

---

## 9.7.0 — 2026-09-15

新件 `FilterPopover` / `countFilterValue`；`FilterPanel` / `FilterPanelTrigger` 标
`@deprecated`（minor：纯增量 + 弃用标注，删除留到下一个 major，见 050 §2）。

owner 2026-09-15 看过 9.6.0 的左侧抽屉在线上的样子后否掉：「筛选也做得太丑了，不能当作
模板，会导致大面积降级……常用的筛选还是放起来，下拉框……把面板作为随按钮位置弹出，不要
左侧抽屉……紧凑布局，不遮挡主页面，应该随选择及时更新，且能看到。按钮不是【应用】应该
是【确定】，布局上可以 grid，一行多项选择，数字在名称后。」

### `FilterPopover`

- 自带触发钮（带已选数角标），气泡贴着按钮弹出（`align` 默认 `end`），**非模态**，
  不遮挡主页面。宽度走 overlay 梯 `xl`。
- **勾一下就生效**：`onChange` 即时回调，没有草稿、没有「应用」；「确定」只收起气泡；
  「清空」立即回调空值。
- 每个维度的选项是网格，**数字跟在名称后面**。`columns` 默认 `auto`：选项多于 12 个排三列、
  气泡加宽到 panel-md，否则两列、overlay xl（三列放进 xl 会截断真实取值）。读法不同的维度用
  `facet.description`，跟在维度名后。
- **向下延伸**：高度用到视口里剩下的空间为止（Radix 可用高度），再多才滚，页脚钉住。
- 定位是「更多筛选」：常用、取值少的维度留在工具行做下拉框，气泡只收剩下的。

### `FilterPanel` 弃用

左侧抽屉、草稿 + 应用、选项单列——三条都是这次被否掉的。标 `@deprecated`，预览面条目
标 pending；下一个 major 删除。

测试：`filter-popover` 9 条（即时回调、确定只收起、清空、数字在名称后、少则两列、多则三列加宽、
显式列数优先、空态与说明、触发钮已选数）。

---

## 9.6.0 — 2026-09-15

表单的必填 / 帮助、两列字段编组、勾选式筛选面板（minor，纯增量：不传即原行为）。
owner 2026-09-15：「新增页面太窄……按一行两条、保持足够的 gap，把提示信息收进帮助
icon，同时体现必填项」「最后的筛选输入，能否左侧弹出面板勾选模式」「弹出面板、抽屉
面板需要系统化一致性」。

### `FieldLabel`：`required` / `hint`

- `required` → 标签后一个星号（`aria-hidden`），读屏念 `requiredLabel`（默认
  `Required`）。此前各表单把「（必填）」写进标签文字，有的写有的不写。只标必填。
- `hint` → 标签后一个帮助图标，悬停或聚焦出现说明（Tooltip，**件内自带
  TooltipProvider**——不是每个消费方都在根上挂了一个）。常驻的 `FieldDescription`
  会把表单拉高一倍，对话框常态就要滚。会随输入变化的提示仍用
  `FieldDescription` / `FieldError`。
- 帮助钮**不在 `<label>` 里**：点它会把焦点交给控件，读屏也会把钮名念进标签。
  给了 `hint` 时外层 span 接过 `field-label` 槽（labeled 方向的网格定位认它），
  标签文字改挂 `field-label-text`，失效态变色两个槽都覆盖。不给 `hint` 时 DOM 不变。

### `FieldGroup columns={2}` / `Field span="full"`

- 一行两个字段，行距列距同为 `lg`；只在 `DialogForm` 的 `lg` / `xl` 里用。
- 长文本、JSON 这类字段给 `span="full"` 占满整行。

### `FilterPanel` / `FilterPanelTrigger` / `countFilterPanelValue`

- 左侧抽屉、`sm` 挡，形态定死（平台面板预设：详情抽屉在右、筛选面板在左）。
- 勾选落**草稿**，「应用」才交出，关闭即丢弃——每勾一下就重查会让服务端分页的表
  来回跳。维度内任一、维度间都要；读法不同的维度（如标签的「全部命中」）给
  `facet.description`。
- 触发钮带已选数角标，放进 `FilterBar` 的筛选组槽。

测试：`form-family` 增 6 条（星号与读屏、无 hint 时 DOM 不变、帮助钮在 label 外、
聚焦出说明、两列与 span、默认单列），`filter-panel` 8 条。

---

## 9.3.0 — 2026-09-11

`ActionMenu` 两件：图标列对齐、尾部危险段自动分隔（owner 2026-09-11）。

两条**都不要求调用方改代码**，但已有菜单的呈现会变。两条也都是同一个病：件把
一件自己能做的事推给了调用方，于是绝大多数调用方没做。

### ① 图标槽位

原实现 `item.icon ? <Icon/> : null`——没图标的项**不占位**，标签顶到最左，比同
菜单里带图标的项左移一整个图标宽。平台上 74 个内联菜单有 11 个是混着写的
（arche 用户页 7 项里 6 项带图标，剩下那一项独自左移）。

- 修在件里不修在调用方：让每个混用菜单补齐图标，等于要求 767 个条目各自找一个
  语义合适的图标，而有些动作本来就没有。**留空位是这件事的正解，空位该由渲染的
  一方留。**
- 整菜单都没图标时**不留空位**——纯文字菜单凭空缩进一格只是浪费宽度。
- 图标与占位符走**同一个 `size-4` 容器**，不各自定尺寸：两支只要有一支用 px、
  一支用 rem，根字号一变就又错开。

### ② 尾部危险段自动分隔

`separatorBefore` 的原注释写着它「用于把危险动作与常规动作分开」，但默认不做。
结果：全站 767 个条目里只有 31 处真写了，而含危险项的菜单有 18 个、其中 **16 个
的危险项已经排在末尾**——判据一直在数据里摆着，却要求每个调用方重复声明一遍。

`separatorBefore` 因此成为**三态**（既有写法全部照旧）：

| 值      | 行为                                                      |
| ------- | --------------------------------------------------------- |
| 不写    | 件自己认末尾那段连续的危险项，在它前面画线                |
| `true`  | 强制画一条，用于**常规动作内部**的分组（「上移/下移」等） |
| `false` | 压制自动判断                                              |

- 已写 `true` 的调用方不受影响：显式值优先，与自动判断撞在一处时**只画一条**。
- **两种情况不自动分隔**，是有意的：危险项散在中间不分（那是调用方的排序问题，
  逐项加线只会把菜单切碎）；整菜单都是危险项也不分（没有「常规段」可分）。
- 「增删改 / 上移下移」这类**常规动作内部**的分组仍归调用方——件推断不出来，
  只有调用方知道哪几项是一组。

回归测试六条，两条改动各自反向验证过（把缺陷放回去，只红该红的那几条）。

---

## 9.2.0 — 2026-09-10

新增 `Field` 的 `orientation="labeled"`：标签左、控件右的网格行。

> 补记于 9.3.0：这一条当时**漏了更新日志**，只改了发版说明。条目按当时的发布内容
> 补写，不追记发布日期以外的事实。

- 轨道宽走 token `--spacing-field-label-{sm,md,lg}`（6 / 9 / 12rem），组件上用
  `labelWidth` 选档，默认 `md`。
- 与已有的 `horizontal` **不是一回事**：后者是 `flex-row`，只给开关行 / 复选行用；
  把 `w-full` 输入框放进去，中文标签会被收缩到 min-content 竖排成一字宽。
  `labeled` 用网格轨道，宽由 token 定不由内容定，标签塌不了。
- 用途是对话框铺**双栏字段**（`DialogForm size="xl"` + `grid-cols-2`）：标签在上
  时八个字段占八行，标签在左则四行，整表可见不出滚动条。

---

## 9.1.0 — 2026-09-07

新增 `align: "numeric"`，与 `money` 并列（owner 2026-09-07）。

数值列从此分**三种**，别混：

| 值的形态                       | 档位        | 为什么                                 |
| ------------------------------ | ----------- | -------------------------------------- |
| 金额（带货币符号）             | `"money"`   | 个位要对齐；符号由调用方给             |
| 纯数值（计数、用量、大小）     | `"numeric"` | 个位要对齐；不带符号                   |
| 短数字（枚举、单位数、百分比） | 默认居中    | 不需要对齐；套定宽块只会让左边空一大截 |

- 9.0.0 把 `numeric` 改名 `money` 时，判据是「纯数字一律居中」。owner 随后补充：
  纯数字**分两种**——需要个位对齐的（计数、用量）和不需要的（短数字）。前者要的正是
  金额那套块，只是不带货币符号。于是 `numeric` 回来，与 `money` **并列**而不是取代。
- **两档当前渲染完全相同**（同一个 12ch 定宽块）。分开命名是为了「这一列是钱」这个
  事实在代码里可见，也让两者日后能各自演进（金额将来可能由件统一补符号或按币种排版）。
  不要因为渲染一样就把它们合成一个——合了以后再想分开，就得回头翻每一个调用点判断
  它是不是钱。
- 加档位是**向后兼容**的：`money` 的行为与调用点一律不变。
- 判据顺带说清楚：要不要走块，看的是**「这一列的值会不会差出量级」**，不是「它是不是
  数字」。

---

## 9.0.1 — 2026-09-07

`money` 档的块宽 16ch → **12ch**（owner 在预览页实测后调）。

16 位是按「金额上限」取的，放进真实表格明显偏宽——短值左边空出一大截。12 位放得下
`¥1,234,567.89` 这类带符号带千分位的百万级金额，覆盖绝大多数行。

判据也跟着改正：这个数**按业务的常见量级取，不按上限取**。让绝大多数行整齐、少数
超长行退化（块左右延伸、那一行个位与别行错开半个超出量），好过让所有行都为一个罕见
的上限让出空白。

---

## 9.0.0 — 2026-09-07

表格：金额档定稿、操作列回定宽、排序标换成上下一对箭头。**含破坏性改名。**

BREAKING CHANGE: `DataTableAlign` 的 `"numeric"` 改名为 `"money"`。传 `"numeric"`
的调用点会编译失败——这是本版的目的。

- **`align: "money"`（原 `"numeric"`）**。改名是为了让规则长在 API 上：**纯数字
  （计数、时长、比率）走默认的居中，不套这个块**（owner 2026-09-07）。档位叫
  「数值」时，计数列会被顺手标上，而它们并不需要定宽块——短值左边会空一大截。
- **金额档的最终做法**：单元格 `text-center`，件内包一层 `min-w-[16ch]` 的
  `inline-block`，块内 `text-right` + `tabular-nums`。块在列内居中、永远碰不到右缘；
  各行的块等宽于是个位对个位。超过 16 位时块左右延伸，不截断不换行（owner 认可这个
  退化：那一行的个位会与别行错开半个超出量，但截掉金额位数不可接受）。
  16 位放得下 `¥1,234,567,890.12`。
  走过两条弯路，都记在 `ALIGN` 的注释里：`pr-2xl`（只加右内边距，不对称反而更靠右）、
  `w-px`（让列收缩到内容宽——方向错了，那是把富余宽度推给其它列，用别的列的宽度换
  这一列的观感）。
- **操作列回定宽 `w-control-3xl`**（原 `min-w-`），与选择列 / 序号列同一种写法。
  `min-w` 在 `w-full` 的自动布局里会让这一列**去分表格的富余宽度**，于是只有一个
  汇聚菜单时列宽也远不止 64px，钉在右侧的锁定列显得又宽又空。并排形态没丢：自动布局
  里 `width` 是建议值，两三个按钮的 min-content 更宽时列照样撑开。
- **可排序表头的方向标换成上下一对箭头**，按当前方向高亮其中一支。此前是单个
  `arrow-up`/`arrow-down`：未排序时画一个淡的向上箭头，本意是「点了会升序」，看起来
  却像「现在是升序」——一个箭头没法同时表达「可排序」与「当前哪个方向」。一对箭头把
  两件事分开：两支都在 = 可排序，哪支亮 = 当前方向。用 `chevron` 不用 `arrow`（10px
  下箭杆糊成一团）；合体的 `caret-up-down` 是一个字形，分不开着色，做不到按需高亮。
- 预览页三处修正（不影响产物）：补 `labels` 消掉中英混编（件是英文托底，调用方漏传
  就会在中文表里冒出「Actions」）；新增走 `money` 的金额列并标 `sortable`；排序函数
  改为按当前排序列排——原先写死按 `calls` 排，标了 sortable 的列点下去数据不动。

---

## 8.0.1 — 2026-09-07

`TableTitleCell` 的字号档回到 14/12，主信息改**加粗**。

- **撤回 8.0.0 的 16/14 缺省**（owner 当天实测）：本件两行的行高是钉死的
  （主 `control-2xs` 20px、辅 `control-3xs` 16px），字号一大就顶开行高，整张表的
  行距被撑得过分。行距原本是合理的，问题出在字号。缺省档改回 `size="md"` =
  主 `label-md` / 辅 `body-sm`（默认全局字号下 14px / 12px）。
- **主信息一律 `font-semibold`**（新增，不是回退）：`label-md` 自带的 `medium`(500)
  与辅助行的 `normal`(400) 只差一档，在 14/12 这种小字号上几乎读不出主次。层次
  因此由**字号 + 字重 + 前景色**三者一起给。
- **小号全局字号档下两行同为 12px，这是预期的**（owner 2026-09-07 明确）。`label-md`
  与 `body-sm` 在 `vx-font-small` 下都解析到 `--vx-text-xs`；此时层次全部由字重承担
  （主加粗 / 辅常规）。8.0.0 的条目把这一档称作「层次塌掉的缺陷」并以此作为提字号的
  理由之一，**那个判断是错的**——字号不是唯一的层次手段。
- `size="lg"`（16/14）保留但不再是缺省，留给低密度、大屏看板一类行高本就宽松的
  场合。**升级影响**：11.0.0 期间没有显式传 `size` 的调用点会从 16/14 回到
  14/12 + 加粗，这正是本版的目的。

---

## 8.0.0 — 2026-09-07

表格列对齐规范重订（owner 2026-09-07）。**含一处破坏性改动**。

- **破坏性：`DataTableColumn.align` 的默认值改为随位置** —— 首列 `left`，其余
  `center`（原先一律 `left`）。规范因此由本件结构性保证，调用方一行 `align` 都不
  必写；首列不是标题的表自己写 `align:"center"` 覆盖。
  **升级影响**：没有显式写 `align` 的非首列会从左对齐变成居中。平台侧粗测约 137
  列受影响，atlas / runos 同样受影响。要保留原样的列显式写 `align:"left"`。
- **新增 `align:"numeric"`** —— 金额/计数列专档：右对齐 + 一档右内边距 +
  `tabular-nums`。`right` 会让数字贴着列的右缘，与相邻列挤在一起；本档把它拉回来，
  整列看上去大致居中而值仍然右对齐。整列宽度一致由表格布局本身保证，不给块设宽度
  （设了反而会在某行内容更长时被撑破）。
- **操作列改右对齐**（原居中）。操作列有两种形态：只有汇聚菜单的，和外放一两个常用
  按钮再跟汇聚菜单的。右对齐让**汇聚按钮在两种形态下落在同一个 x**；而只有一个按钮
  时，64px 列宽减去两侧 `px-md` 后它仍在列中央——两个要求由同一条规则同时满足，
  调用方不必声明自己是哪种形态。前提是汇聚菜单放在最后（既有惯例）。表头不受影响，
  仍居中。
- **`TableTitleCell` 字号提一档**：缺省 `size="lg"` = 主 `label-lg` / 辅 `body-md`，
  默认全局字号下是 **16px / 14px**（原 14/12）。全部按 token 走，三档全局字号
  （`vx-font-small` / 默认 / `vx-font-large`）自动跟随。顺带修掉一个缺陷：小号档下
  原来的两个 token 都解析成 12px，主副标题同号、层次整个塌掉。要老尺寸传
  `size="md"`。
- 修 `DataTable` 文件头两句互相矛盾的注释：一处写「表头与数据行共用同一个 `align`
  轴」，另一处写「表头一律居中，与 `align` 无关」。代码执行的一直是后者，删掉前者。

---

## 7.2.0 — 2026-09-07

`BarChart`：图上现在有数字了。

- **纵轴三档刻度 + 参考线（长显示）**。原来柱子只有相对高度，同样形状的图可能是
  1 万也可能是 100 万，只能翻到下面的表才知道量级。
- **读数条（长显示 + 悬停/键盘切换）**。默认停在**峰值**那一根，所以图上永远有一个
  真数字；鼠标划过或 ← → 键移动时切到那一根，当前那根柱子压暗一档。
- **键盘可达**。图区是**一个** tab 停靠点（不是每根柱子一个），进去后 ← → 逐根移动、
  Home/End 跳首尾。原来唯一的数值出口是柱子的原生 `title`——触屏没有、键盘不可达、
  读屏器只拿到 `role="img"`。读数条是真 DOM 文本，读屏器在浏览模式下读得到。
- 新增两个可选 prop：`peakLabel`（读数条停在峰值时的前缀词，不给就不显示——DS 零
  语言假设，中文不烧死在件里）、`hideAxis`（数据只有两三根、量级一眼能看时关掉纵轴）。
- **调用方不需要改任何代码**，已有的 `<BarChart data={...} />` 自动拿到纵轴与读数条。
  逐柱精确值仍在下方配套的表里（"上图下表"不变）——31 根柱子全标数会挤成一团。
- 读屏器两层角色：外层 `role="group"` 承调用方的 `aria-label`，内层图区才是
  `role="img"`（名字取当前读数，随键盘移动而变）。外层**不能**是 `img`——那会让整棵
  子树变成一张不透明的图，读数条那段真文本反而读不到。

**顺带修两条**（本次改动的测试套件跑出来的，不属 BarChart）：

- `DatePicker`：有选中值时打开日历，显示的是**当月**而不是所选值那个月——只传了
  `selected` 没传 `defaultMonth`，react-day-picker 于是落在今天。选了 8 月 20 日的人
  下次打开看到 9 月，得自己往回翻。这条**一直有测试覆盖却一直是绿的**：测试把值写死成
  "今天所在的月"，判据跟着系统时钟走，跨月才现形。
- `FormPageTemplate` 的粘底条断言停在 10.1.0 改之前的 `bg-background` 上（那次有意改成
  浮起表面 `bg-card + shadow-sticky`），随那次发布就红了，一直没人改。

修完这两条，`design-ui` 的 494 个测试**四次发布以来第一次全绿**。

---

## 7.1.0 — 2026-09-05

（回填：本条与下面三条当时随发布漏写，2026-09-07 按各自的发布提交补上。）

`EditableRow`（新，minor）：详情页里"能改的字段"此前用**禁用的输入框**当展示——禁用态
在视觉语义上是"这个控件不能用"，字是淡的，整页读起来就是一页灰字。规则改为**展示即
文本，激活修改才变成输入框**。本件长在 `DetailList` 里（带编辑态的 `DetailRow`，`dl/dt/dd`
语义照旧），名列宽、虚线、窄屏堆叠与只读行一致；状态与文案由调用方持有（DS 零文案）；
高度按控件撑住、切换不跳；空值画占位；`action` 可整体替换默认的修改/取消；`readOnly`
只剩展示态。

`FormPageTemplate`（修）：`sticky` 动作条此前只补 `bg-background`，与页面同色、滚动时看
不出它是浮着的；且左右无内距，按钮顶到内容区边缘。改为**浮起的表面**（`bg-card + ring +
shadow-sticky`，与 `Section` raised 同一套高度语汇）并加 `px-lg` 与上方卡片内容对齐。
不做"贴底才变色"的滚动侦测：页面短到不滚时它落在内容末尾，浮起的样子同样成立。

> 这次改动**没有同步更新它的测试**（断言仍钉着 `bg-background`），CI 从此转红，直到
> 10.2.0 才修。

---

## 7.0.3 — 2026-09-02

`NativeSelect` 右内距 `pr-2xl` → **回 `pr-xl`**。

7.0.1 把 `pr` 加到 `pr-2xl`（40px）想治 arche `/admins` 的「箭头压字」，**方向错了**：真因
是字号偏大（`body-md`）把值撑长、在 `basis-media-xl`（96px）窄框里溢出，已由 7.0.2 的
FilterBar 压字号根治。`pr-2xl` 反倒白占 8px 文字宽，把刚好放得下的值（如「全部状态」）
又挤出界。回 `pr-xl`（32px）：够让开 16px 箭头（留 6px 净空），又把文字宽还回来。

---

## 7.0.2 — 2026-09-02

`FilterBar` 右段的搜索/筛选控件压小一档字号。

表单控件默认 `body-lg / md:body-md`，放进 FilterBar 的密集筛选行显得偏大。但 `Input` /
`InputGroup` / `NativeSelect` 是全平台共用件，官网/账户的消费级表单也用，全局调小会连
登录/结算一起缩。所以**只在 FilterBar 右段内**、按 `data-slot` 命中这三类控件压字号
（lg→md 窄屏、md→sm 宽屏），只压字号不压高度；别处用法不受影响。

不用 `:is()` / 逗号任意变体（那类 Tailwind 会**静默丢**，是踩过的 CSS 陷阱），三类各写一条。

---

## 7.0.1 — 2026-09-02

`NativeSelect` 右内距 `pr-xl` → `pr-2xl`。**这一条在 7.0.3 被撤回**，判断有误——见 7.0.3。

---

## 7.0.0 — 2026-08-28

跟随 `@vxture/design-tokens@3.0.0`（major：peer 依赖跨主版本）。

- 31 处 `p-none` / `pt-none` / `gap-none` / `inset-x-none` 等改写为 `-0`。tokens
  不再注册 `--spacing-none`，这些类不再产出工具类——改写前它们是有效的，改写后
  仍然是有效的，取值不变（都是 0）。
- `utils/cn.ts` 的 `isSpacingStep` 摘掉 `none`。零档现在走 tailwind-merge 内建
  刻度表，`cn("p-xl pt-0", "p-4")` 这类冲突能被正确合并了（`pt-none` 一直不能，
  见该处注释里 2026-08-03 的实测记录）。
- `DialogTitle` / `AlertDialogTitle` 的 `leading-none` **不变**：它本来就是上游
  原义（`line-height: 1`），此前被间距档解析成 0 才出的叠字。token 修好后这行
  自动正确，代码旁留了判据，避免后人误以为是漏网。

## 6.0.8 — 2026-08-27

修一处**照抄上游抄进来的**无障碍缺陷（patch，050 §2）。

- **修复：`Progress` 的取值从来没传给 Radix，进度条对读屏器永远是「未定」。**

  原实现把 `value` 从 props 里解构走之后，只拿它算填充位移，**忘了传回
  `ProgressPrimitive.Root`**。屏幕上一切正常——色条画在 70% 的位置；语义上
  整条丢了：

  ```html
  <!-- 修复前：value={70} -->
  <div
    role="progressbar"
    aria-valuemax="100"
    aria-valuemin="0"
    data-state="indeterminate"
  >
    <!-- 没有 aria-valuenow -->
  </div>
  ```

  读屏器因此只会播报「正在忙」，播报不出「已完成 70%」；`data-state` 也永远
  停在 `indeterminate`，靠它做样式的调用方拿不到 `loading` / `complete`。

  这一条是**从上游 shadcn 照抄进来的**——本仓文件头写的「结构照 shadcn 官方
  Progress」此前读起来是出处说明，现在它同时是一条线索。

  同一次改动里把位移也接上了 `max`：此前写死按 100 折算，`max={50} value={25}`
  会画在四分之一处，而 `aria-valuenow` 说的是一半——同一条进度条，眼睛和读屏器
  给出两个答案。

  **调用方无需改动**，视觉零变化；此前靠 `[data-state=indeterminate]` 选中
  「有取值的进度条」的样式（如果有）需要改判据。

- 新增 `Progress` 用例 6 条。

## 6.0.7 — 2026-08-26

修一处「看起来在防、实际没防住」的守卫（patch，050 §2）。

- **修复：`InputOTPSlot` 脱离 `<InputOTP>` 单独渲染时直接抛。**

  ```
  TypeError: Cannot read properties of undefined (reading '0')
  ```

  原实现写的是 `inputOTPContext?.slots[index]`——那个 `?.` 是想兜住「没有上下文」
  的，但**它兜不住**：上游的 `OTPInputContext` 默认值是 `createContext({})`，
  一个**真值空对象**。于是 `?.` 永远不会短路，而 `.slots` 必然是 `undefined`。

  这与本仓查过的 6 处死正则同一类：**一个从来没生效过的守卫，比没有守卫更糟**
  ——它让读代码的人以为这里已经防过了。

  改法：可选链一路点到底（`?.slots?.[index]`）。

- 新增表单族用例 35 条（`Field` 一家 / `InputGroup` / `InputOTP` /
  `SegmentedControl`）与反馈族 28 条（`Spinner` / `Avatar` /
  `ResultPageTemplate`）。行覆盖 79.18% → 83.69%，分支覆盖 81.39% → 84.93%。

### 测试基座的两处修补（不影响发布产物）

- **`tests/` 此前从来没被类型检查过**：`tsconfig.json` 的 `include` 只有 `src`。
  接上去之后一次报出 11 条真错误，其中 5 条是无效的图标名（`gear` 不在词表里，
  写在源码里会编译失败，写在用例里一路绿到底）。这条缺口的代价不是假绿——用例
  照样跑、照样通过——而是**用例可以断言一个类型上根本不成立的用法**。已全部修掉，
  `tests` 现已纳入 `pnpm type-check`。

- 补 `document.elementFromPoint` 桩。`input-otp` 在定时器里调它，jsdom 没有——
  抛出来的是**未捕获异常**，不会让哪条用例变红，只让整个进程以非零码退出。
  表现是「用例全过，命令却失败」，最容易被当成 CI 抽风。

## 6.0.6 — 2026-08-26

修一处滚动锁泄漏（patch，050 §2）。

- **修复：从锁滚动的面板切到不锁的面板，退出后整页滚不动。**

  一页上有多个可全屏面板时，`toggle` 换 id 是**切换**而不是先退出——于是
  「A（锁滚动）→ 直接切到 B（`lockScroll: false`）→ 退出」是条常走的路。

  原实现在「这次不锁」那一支里写 `isScrollLockedRef.current = false`，注释说
  「确保上次残留的锁定状态被清除」。清除的却是**记号而不是锁**：body 上的
  `overflow: hidden` 还在，只是没人记得它是谁上的了，于是退出时 `unlockScroll()`
  拒绝还原。

  | 步骤           | 修复前              | 修复后       |
  | -------------- | ------------------- | ------------ |
  | 初始           | `scroll`            | `scroll`     |
  | A 进入（锁）   | `hidden`            | `hidden`     |
  | 切到 B（不锁） | `hidden`            | **`scroll`** |
  | B 退出         | **`hidden`** ← 卡住 | `scroll`     |

  症状离病因很远：用户只会觉得「关掉全屏以后页面卡住了」，而且怎么刷新怎么好，
  下次照样。

  改法：B 不要这把锁，那就**当场还回去**（`unlockScroll()` 自带幂等判断，上次
  没锁时是空操作）。

  这条是**变异测试查出来的**：给「先锁后不锁」那条用例做变异时它没变红，追下去
  才发现不是断言太松，是这一支本身就不对。同 6.0.4 是同一条判据
  （`docs/070-audit-playbook.md` §3.1）。

- 新增原生全屏用例 23 条。此前 `FullscreenProvider` 只测了 pseudo 模式——原生
  那半边一条没走，因为 jsdom 里 `requestFullscreen` / `exitFullscreen` /
  `fullscreenElement` 一个都不存在。现在造了桩，**四档厂商前缀各验一遍**
  （真浏览器里一次只验得了一档），并补上 6.0.4 那个修复的另一半：原生模式退出
  时 `exitFullscreen()` 只调一次。

- 新增 `Skeleton` / `ViewModeSwitch` / `BulkActionBar` 用例 31 条。其中
  `ViewModeSwitch` 那条钉的是件的头注写明、但一直没测的东西：Radix 单选组允许
  取消选中会回空串，**少写那一句忽略，用户点两下当前项就把列表切成「没有视图」**。

  行覆盖 69.63% → 74.78%，未覆盖分支 347 → 273。

## 6.0.5 — 2026-08-26

关掉 SonarCloud 上两条 vulnerability 里属于本包的那一条（patch，050 §2）。

- **`Toast` 的通知 id 从 `Date.now()` + `Math.random()` 换成单调计数器。**

  Sonar 报的理由是「`Math.random` 不是密码学安全的」——**理由不适用**：这个 id
  是 React 的 key 与 dismiss 时的查找键，不需要不可预测，被猜中也什么都做不了。

  **但结论可取**，因为随机数在这里有个真问题：**它可能碰撞**。同一毫秒内连发两
  条、36 进制尾巴又撞上，两条通知就共用一个 React key——后一条把前一条顶掉，而且
  只在手快的时候偶发。

  **没有换成 `crypto.randomUUID`。** 那是安全上下文限定的 API：在 http 页面上
  （内网工具、局域网预览）它是 `undefined`，调用直接抛。为了消一条不适用的告警
  而引入一个只在一半环境里存在的 API，是把告警换成故障。

  单调计数器对这个用途比两者都合适：

  |            | 随机数         | `crypto.randomUUID` | 计数器         |
  | ---------- | -------------- | ------------------- | -------------- |
  | 会不会碰撞 | 可能           | 不会                | **按构造不会** |
  | 环境依赖   | 无             | **安全上下文限定**  | 无             |
  | 可不可测   | 只是大概率成立 | 可                  | **恒真**       |

  计数器放**模块级**而不是 Provider 级：跨 Provider、跨重挂载都不重复，于是上
  一次挂载残留的 `setTimeout(() => dismiss(id))` 不可能误伤新通知。

  id 的格式是**不透明的**，此前此后都不要去解析它。

  新增三条用例（连发三条互不相同、跨两个 Provider 不重复、调用方给了 id 就用
  它），三条变异各自验过。

## 6.0.4 — 2026-08-26

修一处全屏 Provider 的清理时机（patch，050 §2）。

- **修复：`FullscreenProvider` 标着「组件卸载时清理」的 effect，其实每次进出全屏都在跑。**

  它的依赖数组是 `[state.isFullscreen, state.mode, ...]`，而 effect 的清理函数
  **每次依赖变化都会执行一遍**——`state.isFullscreen` 恰恰每次进出全屏都变。
  于是它在**退出**那一帧也跑了一次清理。

  两个后果：

  | 后果                                            | 表现                                                             |
  | ----------------------------------------------- | ---------------------------------------------------------------- |
  | 原生模式下退出会**调两次** `exitFullscreen()`   | 浏览器对第二次调用报错（文档已不在全屏态）                       |
  | `exitFullscreen` 里那次 `unlockScroll()` 被顶掉 | 行为看不出差别，但**唯一的退出路径变成了两条**，谁改一条都不会红 |

  现在改成真正的卸载时清理：空依赖数组，最新状态走 ref 读。两条路（`exit()` 与
  卸载）各自独立，各自有用例钉住。

  这条是**变异测试查出来的**，不是读代码读出来的：删掉 `exitFullscreen` 里的
  `unlockScroll()`，原有用例照样绿——绿的原因不是断言太松，是代码里有条多余的路
  在兜着。判据已补进 `docs/070-audit-playbook.md` §3.1。

- 新增 hooks 行为用例 39 条（`useListPagination` / `useControllableState` /
  `useBreakpoint` / `useMounted` / `useMediaQuery` / `useFullscreen`）。
  行覆盖 48.37% → 63.43%，零覆盖文件 46 → 39。

## 6.0.3 — 2026-08-26

修一处键盘无障碍缺陷（patch，050 §2）。

- **修复：`EntryCard` 只给 `onClick` 不给 `href` 时，鼠标点得到、键盘进不去。**

  本件渲染成 `<a>`。`<a>` 没有 `href` 就**没有角色、不进 Tab 序**——而卡的样式
  一直无条件挂着 `cursor-pointer` 与 hover 变色，看上去完全就是个可点的东西。

  现在按「它到底能不能点」分三种形态：

  | 形态           | 行为                                                        |
  | -------------- | ----------------------------------------------------------- |
  | 有 `href`      | 天然的链接：有 link 角色、在 Tab 序里、Enter 触发           |
  | 只有 `onClick` | 补上按钮语义：`role` / `tabIndex` / Enter 与 Space          |
  | 两个都没有     | **不再画成可点的样子**——去掉 `cursor-pointer` 与 hover 变色 |

  第三条是顺带修的另一半：此前不可点的卡也摆出可点的外观，那是在骗人。

  6.0.2 那一批里这个洞只被测试**钉住了现状**、没修（当时判断是「调用方误用」）。
  第二轮审计把它归到与 `MetricListCard` 同一类：**鼠标那条路能用、键盘那条路不能，
  而外观不提示任何区别**——这是件的问题，不是调用方的。

  顺带删掉一处不可达的防御分支：本件不需要 `MetricListCard` 6.0.2 加的那道
  「只处理落在卡本身的按键」判定——那件的契约里有 actions 槽，卡内本来就会有别的
  控件；本件整卡就是控件，而 `<a>` 里嵌交互元素是无效 HTML。加一道没有任何输入
  能触发的判定，读起来像在防什么，实际是死代码。

## 6.0.2 — 2026-08-26

修一处键盘无障碍缺陷（patch，050 §2）。

- **修复：`MetricListCard` 上键盘按不到行操作，反而进了详情。**

  整卡可点时卡上挂了 `onKeyDown`，它对**任何冒泡上来的** Enter / Space 都响应：
  `preventDefault()` 掐掉内层按钮的原生激活，再把整卡的 `onClick` 触发一遍。
  于是焦点在「更多」上按 Enter，菜单不开、详情打开了。

  鼠标那条路一直是对的——操作区包了一层 `stopPropagation`，所以这个洞只在
  键盘上存在，**看不出来**。

  修法：`if (event.target !== event.currentTarget) return`——焦点在卡内的控件上
  时，那个控件 own 这次按键。同时补了正向用例（卡本身聚焦时 Enter 与 Space 仍要
  响应），免得把「该触发」也一起修没了。

  SonarCloud 早就报过这个位置（`jsx-a11y` 那条 MINOR），2026-08-25 被我判成误报
  并写进了 `docs/audit/known-false-positives.md`——**判错了**。当时的理由是
  「键盘 Enter 会产生一个冒泡的 click，同样被 stopPropagation 拦住」，漏了一步：
  **keydown 先于 click 发生**，preventDefault 之后那个 click 根本不会产生。
  登记已更正并保留原文。

- **文档更正：`AlertDialog` 的 Esc 是关得掉的。** 头注原写「Esc 与点遮罩也不关」
  ——错了一半。实测：Esc 触发 `onOpenChange`，外点不触发。而 Esc 能关是**对的**：
  没有键盘出路的模态是键盘陷阱。「要求表态」靠的是拿掉随手可点的出口（无 X 钮、
  外点不关），不是堵死所有出口。03 §1 同步更正。

## 6.0.1 — 2026-08-26

修一处静默失效（patch，050 §2）。

- **修复：`Drawer` 的宽度挡位一直是死的。** 传 `width="sm" | "md" | "lg"` 没有
  任何效果——抽屉一律渲染成 `w-full max-w-panel-lg`。

  病因：挡位类名排在基础类 `w-full` **之前**传给 `cn`，而 `cn` 把
  `--container-*` 登记进了宽度组（`utils/cn.ts` 里那段注释讲的正是这件事），
  于是 `w-panel-md` 与 `w-full` 同组冲突、后写的赢，挡位被 tailwind-merge
  静默丢掉。**没有任何报错**，DOM 上连那条类都不剩。

  这与文件头注释警告的「两条路不能混」是同一个后果、不同的机制：那段注释防的是
  class 与 inline style 打架，而实际发生的是 class 与 class 在合并阶段就分出了
  胜负。注释记住了教训，拦不住这个变体。

  修法：挡位移到基础类之后。2026-08-26 写抽屉宽度回归测试时查到，已由测试钉住。

## 6.0.0 — 2026-08-25

破坏性（major，050 §2：改组件 props）：**`variant="destructive"` 的 Button 也
必须写明为什么不设防。** 破坏性确认契约的最后一个洞补上了。

### 补的是哪个洞

4.0 把 `danger` 收进 `ActionMenuItem` / `BulkActionBarItem` 的判别联合时，漏掉了
第三个载体——裸的 `<Button variant="destructive">`。4.1 的处置是把文档改诚实、
给出两条 grep 的清点口径。

**那让文档对一个洞诚实，并没有把洞补上。** 具体后果：accounts 的删 passkey 按钮
（红色、不可逆、删的是安全凭据，删掉最后一个就把自己锁在外面）一直不设防，而
`grep -rn confirmExempt` 会把 accounts 报成干净。清单不完整就不能当清单用。

而当时给出的第二条 grep（`grep 'variant="destructive"'`）是**纯人工纪律、没有
任何强制力**——正是这套契约一开始要消灭的东西：「现在判不了，因为没有可判的形状」。
本版把形状补齐。

### 分工：原语只管形状，契约由组合件承担

| 载体                        | 层        | 承担什么                                                                      |
| --------------------------- | --------- | ----------------------------------------------------------------------------- |
| `Button` / `ActionButton`   | base      | **类型义务**：`variant="destructive"` 必须写 `confirmExempt` 说明为什么不设防 |
| `DestructiveButton`（新增） | composite | **拦截**：收 `confirm` 契约，自己弹 `ConfirmDestructive`                      |

这个分工不是设计洁癖，是被守卫逼出来的。第一版让 base 的 `Button` 直接收
`confirm` 并自己弹框，`check-server-entry-safety` 当场报红：

```
✗ @vxture/design-ui 的 /server 入口在 react-server 下求值失败：
  React.createContext is not a function
```

原因：`MetricCard` 在 server-safe 名单里且引了 `Button`，于是
`Button → ConfirmDestructive → AlertDialog` 把 Radix 的 `createContext` 拖进了
`/server` 入口。**一个能弹模态的 base 原语就不是 base 原语。** 改成现在这个分工
之后 `Button` 零新增 import，server-safe 子集原样保住。

顺带作废了第一版为解引用环做的两项改动（把 `buttonVariants` 拆成独立模块、把
`ConfirmDestructive` 移进 `base/overlay/`）——没有环了，两项都不必要。后者当时的
理由也是错的：「依赖全在 base 所以它属于 base」恰恰说反了，**由 base 单件拼装
正是 composite 的定义**（见 `composite/index.ts`）。

### 契约

```tsx
// 要拦
<DestructiveButton confirm={{ verb, target, consequence, onConfirm }}>
  Revoke
</DestructiveButton>

// 不拦，写明为什么（理由可 grep）
<Button variant="destructive" confirmExempt="确认在流程第二步">…</Button>
```

`variant="destructive-strong"` **不要求**：按 03 §3 它是落锤档——确认对话框里的
那个提交按钮。要求落锤自己再确认一次是循环。

`ActionButton` 透传 `ButtonProps`，自动跟着收紧。为此把它的 `Omit` 换成
`DistributiveOmit`：在联合上做 `Omit` 必须分配到每个分支，否则 TS 会先把分支并成
一个「什么都可选」的对象再删键，`variant` 与 `confirmExempt` 的绑定关系当场丢失
——`ActionButton` 就成了绕开契约的后门。

于是清点口径回到**一条** grep：`grep -rn confirmExempt portals/`。

### 迁移

所有 `<Button variant="destructive">` 与 `<ActionButton variant="destructive">`
会编译失败。要拦的换成 `DestructiveButton` 并给 `confirm`，不拦的写一句
`confirmExempt` 理由。

accounts 那个删 passkey 的按钮：

```tsx
<DestructiveButton
  confirm={{
    verb: "Revoke",
    target: passkey.name,
    consequence: "…",
    preconditions: [
      { label: "至少还有一把可用的 passkey", met: others.length > 0 },
    ],
    onConfirm: () => revoke(passkey.id),
  }}
>
  Revoke
</DestructiveButton>
```

`variant` 是运行时值时（遍历全部挡位的画廊）选不出分支，需要回收一次类型——
预览面的 `galleryVariant` 是这个写法的样板。

`DestructiveButton` 不开 `variant`（按定义就是 destructive 入口档）也不开
`asChild`（渲染「按钮 + 对话框」两个节点，塞不进 `Slot` 的单子元素约束）。
`AlertDialogTrigger asChild` 这类场合用 `Button` + `confirmExempt`。

### 守卫

`check-i18n-seam.mjs` 补一条豁免：`confirmExempt` 的值不受「渲染文案一律英文」
约束。它**从不进 DOM**（`Button` 把它解构丢掉后才展开 props，落到元素上会变成
React 不认识的属性并报警告），作用全在类型层与 `grep`——和注释同一类，是写给
维护者的散文，而本仓的维护语言是中文。判据仍是二值的：整行含 `confirmExempt`
即跳过，不做语义推断。

## 5.0.0 — 2026-08-25

破坏性（major，050 §2）：**默认文案全部由中文改为英文托底，应用一律传参。**

### 为什么是破坏性的

类型没动，一个字段都没增删——**但每一个消费方的界面都会变，且不会有任何编译
错误**。这正是 050 §2 对 token 删改坚持按 major 处理的那条理由：「不会报错，只会
静默失效」不做「应该没人用」的推定。行为层面同理。

现在全靠默认值出中文的产品（opera、accounts）会看到英文，需要在调用点传参。

### 判据：托底，不是产品语言

**英文默认值是托底。** 它的意义在于漏传时界面仍然可读、不出现空字符串或
`undefined`，而不是让人依赖它——**英文默认值出现在生产界面上，说明有人忘了传，
不是一种受支持的配置**。所有应用都应当传参，中文单语的产品也不例外。

为什么托底必须是英文：DS 不知道消费方说什么语言，件内写中文就等于替某一个产品
做了语言选择，而那个选择对别的产品是错的。英文是这里唯一中立的那一个。

**这一版之后，件完全兼容 i18n**：任何一处渲染文字都换得掉，包括只给读屏听的
`aria-label` 与 `sr-only`。4.1–4.2 补出口、5.0 把默认值换成不预设立场的那个——
两步是同一件事的两半，到这里才闭合。DS 仍然没有也不打算有 locale 上下文：
**兼容 i18n 不等于承担 i18n**，翻译是产品的事。

### 改了什么

83 处默认文案，20 个文件（design-ui 组件 + 伞包 shell 层 + 图标字典）。全部是
默认值替换，**props 与类型零改动**。

| 层            | 件                                                                                                                                                       |
| ------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| base          | `Banner` `Toast` `Command` `Drawer` `Pagination`                                                                                                         |
| composite     | `ActionMenu` `BulkActionBar` `DataTable` `FilterBar` `ViewModeSwitch` `Combobox` `DatePicker` `DialogForm` `FieldTier` `ConfirmDestructive` `SectionNav` |
| shell（伞包） | `ShellChrome` `ShellLauncher` `ShellSearchBox` `ShellSidebarNav`                                                                                         |
| 其他          | `iconDictionary` 的 14 个分组名                                                                                                                          |

几处值得单独说：

- **`ConfirmDestructive.titleTemplate` 默认值由 `"{verb}{target}？"` 改为
  `"{verb} {target}?"`。** 4.1 加这个 prop 是为了把语序还给调用方，但默认值仍是
  中文语序；现在默认值也中立了。中文产品传 `"{verb}{target}？"`。
- **`BulkActionBar.selectionTemplate` 由「已选择 {count} {noun}」改为
  `"{count} {noun} selected"`，`noun` 默认值由「项」改为 `"items"`。** 这两条必须
  一起改——语序和量词是同一句话的两半，只改一个会得到 `已选择 3 items`。
- **`Pagination` 的计数语**由「共 N 条记录 / 当前筛选 M 条」「第 N / M 页」改为
  `N records / M filtered`、`Page N of M`。逃生口 `countLabel` 不变。

### 守卫换成了二值判据

`check-i18n-seam.mjs` 从「中文有没有覆盖出口」改成「**剥掉注释后不许出现中日韩
字符或全角标点**」。

上一版靠启发式分辨形参默认值、`DEFAULT_*` 常量、跨行 `??` 兜底，每一条都可能误
判，实测里踩过两次（单行常量声明打穿常量块追踪、JSX 属性与形参默认值正则无法
区分）。英文做基准之后判据变成二值的：没有启发式，就没有误判，也不存在「看起来
在查其实没查」的中间态。

全角标点必须一起查：`"{verb}{target}？"` 里没有一个汉字，只有一个全角问号——
只扫汉字的那一版从头到尾没报过它。

**注释不受此限**：注释是写给维护者的，本仓的维护语言仍是中文。

### 迁移

不会编译失败，所以**没有编译器帮你找**。按 05 §3.1 的三档收法在调用点传参：
一两条走独立 prop，三条以上走 `labels` 对象，拼句子的走模板。

建议各产品建一份共享的 labels 常量，而不是逐个调用点手写——否则同一个「取消」
会在不同页面上长出不同的写法，那正是 DS 收口这些文案要解决的问题。共享常量同时
让「哪些还没传」变得可清点。

英文产品同样要传：默认值只保证漏传时不难看，不保证那句话适合你的语境。

## 4.2.0 — 2026-08-25

全面整改文案出口（minor，050 §2：新增能力 minor）。**全部向后兼容**，新增的
都是可缺省 prop。

### 起因

4.1.0 只在 `ConfirmDestructive` 里关掉了「件替调用方决定语序」这个洞。全仓审计
（剥注释后扫中文字面量，逐个核实有无覆盖出口）发现它不是一个件的毛病：**7 个件、
15 处中文写死在组件里，调用方覆盖不掉**。其中 `DialogForm` 的「处理中…」与
4.1.0 刚修掉的那一行**一模一样**——我修了自己新写的件，没回头看它抄自哪里。

判据不是「不许写中文」，是**每一处文案都得有办法被调用方换掉**。DS 全仓十几处
中文默认值（`cancelLabel` / `previousLabel` / `placeholder`）本来都守着这条，破
它的这 15 处只是没人查。

### 新增的出口

| 件              | 新增                                                                                                                      |
| --------------- | ------------------------------------------------------------------------------------------------------------------------- |
| `DataTable`     | `labels`（`expand` / `selectAll` / `deselectAll` / `selectRow` / `rowActions`）——其中 `rowActions` 是**可见表头**「操作」 |
| `BulkActionBar` | `selectionTemplate` / `toolbarLabel` / `clearLabel`                                                                       |
| `Pagination`    | `pageSizeLabel` / `pageSizeOptionTemplate` / `pageSizeAutoLabel`                                                          |
| `Toast`         | `ToastProvider` 的 `regionLabel` / `dismissLabel`                                                                         |
| `Drawer`        | `closeLabel` / `fallbackTitle`                                                                                            |
| `Banner`        | `dismissLabel`                                                                                                            |
| `DialogForm`    | `pendingLabel`                                                                                                            |

收法照 house 分工：一两条走独立 prop，三条以上走 `labels` 对象与默认值合并
（`ShellSearchBox` / `ShellSidebarNav` 同款）。

**两处收的是模板不是词**，因为它们拼句子：`BulkActionBar.selectionTemplate`
（默认「已选择 {count} {noun}」）曾只开 `noun` 一个口子，而英文得是
`{count} {noun} selected`——给一个词换不出那句话；`Pagination.pageSizeOptionTemplate`
同理。语序是语法不是词汇，件替调用方拼串就等于替它定了语序。

只给读屏听的 `aria-label` / `sr-only` 一并收口：读屏听见的也是话。

### 新增守卫：`check-i18n-seam.mjs`

整改这一批只清掉了当下，下一个件照样会写死而没有任何东西拦得住——这正是 4.0.0
把 `danger` 收进类型时用过的论证。故落成守卫，已进 `pnpm guardrails`
（`pnpm lint:design-i18n`）。

认四种出口：形参默认值、`DEFAULT_*` / `*_LABELS` 常量、`??` 兜底、带理由的豁免
清单。两条实测：**当前代码零违规；对 4.1.0 的代码精确报出那 15 处，一处不多一
处不少。**

写这条守卫时自己踩了两个坑，都记在脚本头注里：一是用「独占一行的 `];`」找常量块
收尾，被单行声明 `const DEFAULT_PAGE_SIZES = [...]` 打穿，`inDefaults` 再没关掉，
**从那一行起整个文件不再检查**——守卫自己静默停止守卫，比没有守卫更坏；二是
`ariaLabel="每页条数"`（JSX 属性）与 `ariaLabel = "每页条数"`（形参默认值）在正
则眼里没有区别，靠「形参默认值必然以逗号收尾」才分得开。

### 文档

05 新增 §3.1「件内文案：中文默认值，但必须留得出出口」，写明三档收法与「语序是
语法不是词汇」这条判据。

**留出口不等于做 i18n**：DS 没有也不打算有 locale 上下文，翻译是产品的事。本版
只是把决定还回去。

## 4.1.0 — 2026-08-25

三修一勘误（minor，050 §2：新增能力 minor）。全部向后兼容——4.0.0 的调用点
不改也能编译。

来自消费侧评审（opera，迁移 32 处前的验收）。判据统一用仓里那两条边界：
`composite/index.ts` 的「零业务」与 `tone.ts` 的「DS 一旦收下产品的判断就等于
把业务语义焊了进来」。

### 修：件替调用方决定了语序（A）

4.0.0 直接拼 `${verb}${target}？`——**DS 握着「一个门户说什么语言」这个决定，
而那本就不是 DS 的**。英文下渲染成 `Deletemodel service gpt-4o？`：动词与对象
之间没有空格，句尾一个全角问号，且调用方无论如何覆盖不掉。

新增 `titleTemplate`（默认 `"{verb}{target}？"`，英文传 `"{verb} {target}?"`）。
`verb` / `target` 仍必填：契约要的是「标题由动词加对象构成、按钮用动词本身」这条
**形状**，不是某一种语言的语序。形状留在 DS，语法交还调用方。

同时把两处漏开口子的文案补成 prop——`pendingLabel`（默认「处理中…」）与
`blockedHint`。DS 全仓十几处中文默认值（`cancelLabel` / `previousLabel` /
`placeholder`）无一例外都是可覆盖的 prop，4.0.0 这两处破了 house 约定。

这不是新增 i18n 能力：DS 至今没有、也不该有 locale 上下文。只是把决定还回去。

### 修：`met: boolean` 说不出「查不到」（C）

`DestructivePrecondition` 新增 `unknown?: boolean` 与 `note?: string`。

**`met` 仍是唯一的门闩，`unknown` 只管显示。** 这两件事分开是有意的：「读不到
检查单时挡住还是放行」是产品的风险判断（opera 判「门槛失效必须失效在保守那一
侧」，另一个产品判「读不到就放行、只提示」并不比它蠢）。DS 收下这一条就等于把
风险偏好焊进来，正是 `tone.ts` 拒绝过的那类事。所以放不放行由调用方在 `met` 上
表态，本件只把「查不到」和「确认没满足」在视觉上分开：红叉 vs 灰问号。

三态本身不是业务——`Checkbox` 的半选态早就承认「布尔说不出的第三态」是形状问题。
少了它，`met: false` 会让界面说假话：「服务已下线」被划掉标红，而事实是根本没
查到它下没下线，运营会跑去下线一个已经下线的服务。

`note` 不设默认文案：「读不到，按未满足处理」这句话本身就断言了保守政策。

### 勘误：契约的边界与清点口径（B）

4.0.0 的更新日志与 03 §3 写了 `grep -rn confirmExempt` 给出「本产品有多少个不设
防的红色动作」的**完整**清单。这句是错的——判别联合只管 `ActionMenu` 与
`BulkActionBar`，够不到裸的 `<Button variant="destructive">`。一份自称完整的
清单比没有清单更坏。正确口径是两条 grep 一起看，见 03 §3。

`Button` 不收这条联合，理由不是成本是边界：`variant="destructive"` 的红按钮完全
可能是「打开一个多步流程」「打开 DialogForm」的入口，确认在下一屏。强制它带
`confirm` 等于 DS 判定「红＝此处立即落锤」，而那是产品的 UX 判断。这类按钮自己
组合 `ConfirmDestructive`（它本就能独立使用）。

### 验：与 step-up 叠加（D）

admin 删角色是 `runWithStepUp(() => deleteOperatorRole(id))`——确认之后还有一道
TOTP。**DS 不建模 step-up**：认证策略是产品的，接缝就是 `onConfirm` 返回的
Promise，谁 resolve 它是调用方的事，无需任何 API 改动。

但两层 radix 模态叠加时的焦点陷阱是形状问题、是 DS 的活，故在预览面新增
`ConfirmStepUp` 条目按 admin 的真实形态摆出来：确认框停在「处理中」，step-up
的 `DialogForm` 压在上面，resolve 后两层依次退场。

## 4.0.0 — 2026-08-25

破坏性（major，050 §2）：**`danger` 从视觉开关变成带拦截的契约。**

### 为什么是破坏性的

`ActionMenuItem.danger` / `BulkActionBarItem.danger` 此前是 `boolean`，只做一件
事——把这一项染成 destructive 语义色。红色让运营以为「系统知道这很危险」，而
系统其实什么都没做：**视觉上警告、行为上不设防**，两件事凑在一起比不染红更
危险。默认值也是反的——不写确认是零成本，写确认要自己拼一整个对话框。

03 §3 早就写了「真正的拦截交给二次确认，不靠按钮颜色吓人」，05 §46 早就把确认
文案钉成三件套（标题「{动词}{对象}？」＋后果一句＋按钮用动词本身）。两条都只
活在散文里，没有载体，于是只有读过文档的人写得出来。本版把它们变成必填参数。

判据放进**类型**而不是 guardrail 脚本：`scripts/guardrails/check-*` 的消费方那
一半扫的是 `portals/**`，DS 仓里没有这个目录，看不见任何调用点。lint 规则不跟
着 npm 包走，类型跟着包走。

### 新增

- **`ConfirmDestructive`**：破坏性确认件，四项契约——`verb`（动作名）/
  `target`（对象）/ `consequence`（后果一句，必填）/ `preconditions`（前置条件）。
  标题与确认钮文案由 `verb` + `target` 生成，写不出「确定」这种没有动词的按钮。
  与 `AlertDialog` 的关系照 `Dialog → DialogForm`：那个是容器，这个是契约。
  `AlertDialog` 此前在全仓零消费——组装成本全在调用方，正是这件要消掉的东西。
- **前置条件是判据不是提示语**：`preconditions` 收 `{ label, met }`，任一条
  `met: false` 即禁用确认钮并标出是哪条没过。opera 那几个删除框写的「必须已
  下线、且没有入口或授权还在引用它」本就是算出来的结论，只渲染成文字等于把它
  扔了。到这一步「红」与「拦」才真的是同一个决定。
- `onConfirm` 返回 Promise 时本件自接「处理中」态：成功才关，失败不关（用户
  得看见自己按的那一下没成），错误重新抛出、不吞也不自造错误 UI。

### 破坏

`ActionMenuItem` / `BulkActionBarItem` 收为判别联合。`danger: true` 必须二选一：

| 写法                          | 含义                                                                                      |
| ----------------------------- | ----------------------------------------------------------------------------------------- |
| `confirm: DestructiveConfirm` | 由本件弹确认框，落锤走 `confirm.onConfirm`（此分支不再收 `onSelect`，两个都接会一起触发） |
| `confirmExempt: string`       | 显式豁免，**理由必填**                                                                    |

豁免用带理由的字符串而不是 `confirm: false`，是为了让它**可清点**：
`grep -rn confirmExempt` 列全所有已声明豁免的红色动作。这比报错更有用——它给的
是清单，不是错误。

> **勘误（4.1.0）**：此处原写「一次列全『本产品有多少个不设防的红色动作』」，
> 是错的——契约够不到裸的 `<Button variant="destructive">`。正确口径与理由见
> 4.1.0 条目。什么时候该用：动作本身可撤销（归档、下线），
> 或上游已经拦过一道；「用户嫌麻烦」不是理由，那说明这一项不该染红。

### 迁移

所有写了 `danger: true` 的调用点会**编译失败**，这是本版的全部意义。逐个补
`confirm`，或写一句 `confirmExempt` 理由。批量条（`BulkActionBar`）的
`confirm.target` 由调用方拼（「选中的 12 个模型服务」）——只有调用方知道选中
的是什么、有几个，而确认框的标题必须说出这两样。

顺带：`ActionMenu` 在菜单关闭时若正要开确认框，跳过 Radix 的焦点找回，交给
AlertDialog 自己的焦点陷阱——否则焦点先落回「⋮」按钮，键盘用户开出确认框却
发现焦点不在框里。

## 3.2.1 — 2026-08-24

修样式（patch，050 §2）。

- **`DialogForm` 字段区滚动上限 60vh → 70vh。** 3.2.0 引入 xl 档后，对话框的
  常态是双栏长表单：60vh 在 1080p 只给 648px，紧凑密度排完（实测 617px）几乎
  贴顶，笔记本高度必出滚动条——而 xl 档的目标恰是「整表可见、滚动只是兜底」。
  70vh 下整体高度（内容 + 标题页脚 ≈ +180px）在 800px 视口内仍放得下。
  这一改本应随 3.2.0 一起出（同一次验证里补的），提交时遗漏。

## 3.2.0 — 2026-08-24

一修一增（minor，050 §2：新增能力 minor、行为 bug patch，取高位）。

- **修复：`ActionMenu` 打开的 Dialog 关闭后整页点不动。** Radix 的模态
  DropdownMenu 与模态 Dialog 各自往 `<body>` 挂 `pointer-events: none`，
  菜单项 `onSelect` 里打开对话框时，菜单的解锁与对话框的加锁同拍竞争，
  对话框关闭后锁**残留**，整页失去交互、只能刷新浏览器。2026-08-24 在
  opera 模型服务页以真实鼠标事件复现（菜单 → 编辑 → 取消 → body 恒为
  `pointer-events: none`；页首按钮直开的对话框则始终干净——锁死只发生在
  「菜单开出来的对话框」这条路上）。修法：菜单改 `modal={false}`，不再
  上锁即无竞争；外点关闭、键盘导航、焦点找回不受影响。行菜单本就不需要
  锁住全页的强度。
- **新增：`DialogForm` 尺寸档 `xl`（`max-w-panel-xl`，928px）。** panel 梯
  的超宽档此前只有裸 `DialogContent` 能用，DialogForm 封死在 lg——字段多的
  注册表单只能挤单列、靠 60vh 滚动。xl + 双栏排版让内容装得下，滚动条
  自然不出现。
- **修订：`DialogForm` 页脚上方加 `Separator`。** 对话框骨架定稿（owner
  2026-08-24）：标题在上 / 内容区 / 分割线 / 操作区下对齐。分割线同时是
  「页脚钉住」的视觉边界——长表单滚动时内容不再看起来直接顶着按钮。

## 3.1.4 — 2026-08-22

修 `repository.url` 的 scheme 前缀（patch，050 §4）。

- GitHub Packages 的「Repository source」校验只认裸的 `https://github.com/OWNER/REPO.git`，
  `git+https://...` 会被当成非 GitHub 来源，判定为无法校验。去掉 `git+` 前缀，
  `type`/`directory` 不变。

## 3.1.3 — 2026-08-21

修 `package.json` 的 `repository` 字段（patch，050 §4）。

- GitHub Packages 的「Repository source」是直接读 `package.json` 的 `repository`
  字段渲染的，不是按实际发布来源自动判定——3.1.2 的字段值不准确，包设置页因此
  显示归属有误。改指 `vxture/vxture-design`。

## 3.1.2 — 2026-08-21

重新建立本包的可发布状态（patch，050 §4 / issue #1）。产物内容与 3.1.1 一致，
版本号 +1 仅为解除发布流水线的历史阻塞。

## 3.1.1 — 2026-08-21

修 bug，属 patch（050 §2）。

- **修复：`/server` 入口在 react-server 运行时求值即崩。** 复现命令：
  `node --conditions react-server -e "import('@vxture/design-ui/server')"` →
  `The requested module 'react' does not provide an export named 'createContext'`。
- **根因**：`icons/iconRegistry.ts` 引的是 Phosphor 的**裸入口（CSR 构建）**，它在
  模块作用域调用 `createContext`，而 react-server 运行时的 react 不导出该符号。
  `server.ts` 的注释早就写死「不得导出任何 import ../../icons 的组件」，但导出列表
  里有 **6 个**违反此规则：StatusBadge / EmptyState / Banner / Section / MetricCard /
  MetricGrid（原始报告只点了前两个，实测是六个）。
- **修法**：改引 `@phosphor-icons/react/ssr`——同一套图标的无 context 版本。
  没有采用 issue 备选的「移出 `/server` 导出列表」：那会砍掉六个最常用的
  server-safe 组件，是把契约缩到实现能满足的范围，而不是修实现。也没有采用
  「惰性化」：SSR 构建让 `Icon` **真正可在 RSC 渲染**，不止于可求值。
  `weight` 等仍是普通 prop；本仓未使用 `IconContext`，无功能损失。
- **不影响生产**：webpack 的 DCE 一直把未使用的重导出摇掉，线上从未复现；
  炸的是 `next dev`（无 DCE、全量求值）——消费方本地开发该页面 500。
- **配套守卫**：新增 `scripts/guardrails/check-server-entry-safety.mjs`，用
  `--conditions react-server` 真的 import 一次产物（复现命令即验收命令），已接入
  CI 与发布流水线。6.1.0 发版正是漏了这一条。

## 3.1.0 — 2026-08-21

新增组件属 minor（050 §2）。

- **新增：`BarChart` 柱状图（Components - Pattern）。** DS 首件数据可视化原语
  （owner 2026-08-21：用量分析各板块「上图下表」，图为全宽柱状图）。等宽柱铺满
  容器、组内最大值归一；柱体 `bg-primary` 与 Progress 填充同色，零值留
  `bg-accent` 基线刻度；柱高为运行时数据走内联 style（Progress 先例）；横轴
  标签抽样显示（`labelEvery`），逐柱精确数值归下方配套表格。预览面已注册。
- **修订：`DataTable` 操作列 定宽 64px → min 64px**（owner 2026-08-21 表格
  规范修订）。支持「主操作按钮 + ⋯ 菜单」同格的单操作列（订单表先例）；
  单图标场景仍收敛回 64px，选择/序号列保持定宽不变。

## 3.0.0 — 2026-08-18

DS 治理批次（2026-08-18 审查 + shell-template 退役战役）收口。删除公开导出属破坏性
——major。

### 💥 Breaking

- **全屏死零件删除**：`FullscreenContainer`、`FullscreenToggle`、`Portal` 三件组件
  及其 props 类型（`FullscreenContainerProps` / `FullscreenContainerRef` /
  `FullscreenToggleProps` / `FullscreenPortalProps`）——全仓零消费（owner 批）。
  **存活链不变**：`FullscreenProvider` + `useFullscreen`（经伞包
  `ShellFullscreenToggle` 消费）照常；迁移即改用它们。
- **`SegmentedControl` 选中态视觉改判**（API 不变）：胶囊槽 + 品牌实底滑块 →
  `rounded-lg` 槽 + `rounded-sm` 浮起面片（`bg-card` + `text-primary` +
  `shadow-xs`，同心圆角），向用户面板原型收敛、全 token 实现。视觉变更故随
  major 批说明；调用方零改动。

### ✨ 新增

- **`DialogContent.width` 档位 prop**（`sm 28 / md 32 / lg 42 / xl 58rem`，缺省
  md）与配套导出 `DIALOG_WIDTHS` / `DialogWidth`。xl 档为 T2 panel 梯新档的
  @theme 字面量消费方。
- **`ShellPanelRow.danger`**（经伞包生效）：面板动作行 destructive 语气——红字 +
  hover 淡红底，与 ActionMenu 的 danger 同一判断。

---

## 2.0.0 — 2026-08-17

首个版本。从 `@vxture/design-system` 拆出的**无状态组件层**：基础组件、平台图案、
图标、hook 与工具函数。不含任何运行时接线——主题、密度、字号偏好这些带 React
context 的东西留在伞包。

### 内容

- `components/ui` —— 基础组件与平台图案
- `components/ai` —— AI 形态组件
- `components/layout` —— container / stack / grid / fullscreen
- `icons`、`hooks`、`utils`、`types`

### 入口

- `.` —— 全量，带 `"use client"`
- `./server` —— 可在 RSC 中渲染的纯叶子子集，**刻意不带** `"use client"`

### 已知状态

**重写已收口。** `scripts/guardrails/check-component-classes.mjs` 实测：103 个组件、
1116 处类名全部由配方生成，无手写视觉片段，无豁免，PENDING 清单为空。

批次开启时还有 43 个组件依赖已退役的遗留 BEM 类名、当时渲染无样式——那一档是本包
从 `@vxture/design-system` 拆出来的起点，不是现在的状态。

版本号从 2.0.0 起：本包虽是首次发布，但按 050 §2.1「major 号在批次开启时已定，批次内
不重复决策」，随三包同批的号走，而不是自己另起一个 1.0.0。

### 依赖说明

对 `@vxture/design-tokens` 的依赖是**样式依赖，不是代码依赖**：组件里没有一行
`import` 指向它，但组件用的每个工具类（`bg-primary` / `p-md` / `shadow-raised`）
都由它的 CSS 注册。不装它，组件渲染出来没有任何样式。
